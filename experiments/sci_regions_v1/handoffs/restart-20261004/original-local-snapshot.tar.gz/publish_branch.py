"""Publish only the SCI-REGIONS research directory through GitHub's Git Data API."""
import base64
import json
import subprocess
import time
from pathlib import Path

REPO = "Talchain/Inference-Service-Layer"
BASE = "fdb51e84a673993de7cddb85d5b963741941b80a"
BRANCH = "sci/regions-v1-prototype"
ROOT = Path("/private/tmp/sci-regions-v1/Inference-Service-Layer-fdb51e84a673993de7cddb85d5b963741941b80a/experiments/sci_regions_v1")
PREFIX = "experiments/sci_regions_v1/"
FILES = [
    "SCI-REGIONS-v1.md", "README.md", "schema/RegionRequestV1.schema.json", "schema/RegionResultV1.schema.json",
    "fixtures/FROZEN.json", "schema_validation.py", "regions.py", "synthetic.py", "oracle.py", "r3b_adapter.py",
    "study.py", "visual.py", "mutant_checks.py", "package_results.py", "tests/test_regions.py",
    "output/results.json", "output/results.zip", "output/comparison.html", "output/run-manifest.json", "output/mutant-evidence.json",
]


def api(endpoint, method="GET", payload=None):
    command = ["gh", "api", f"repos/{REPO}/{endpoint}", "--method", method]
    if payload is not None:
        command += ["--input", "-"]
    for attempt in range(3):
        process = subprocess.run(command, input=None if payload is None else json.dumps(payload).encode(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if process.returncode == 0:
            return json.loads(process.stdout)
        if attempt == 2:
            raise RuntimeError(f"GitHub {method} {endpoint}: {process.stderr.decode()[:500]}")
        time.sleep(2 ** attempt)


def main():
    ref = api(f"git/ref/heads/{BRANCH}")
    if ref["object"]["sha"] != BASE:
        raise RuntimeError("branch moved from pinned base; refusing to overwrite")
    base_tree = api(f"git/commits/{BASE}")["tree"]["sha"]
    entries = []
    for name in FILES:
        path = ROOT / name
        data = path.read_bytes()
        binary = name.endswith(".zip")
        blob = api("git/blobs", "POST", {"content": base64.b64encode(data).decode() if binary else data.decode(), "encoding": "base64" if binary else "utf-8"})
        entries.append({"path": PREFIX + name, "mode": "100644", "type": "blob", "sha": blob["sha"]})
        print(name, len(data), blob["sha"][:10], flush=True)
    tree = api("git/trees", "POST", {"base_tree": base_tree, "tree": entries})
    commit = api("git/commits", "POST", {"message": "Add offline SCI-REGIONS v1 research prototype", "tree": tree["sha"], "parents": [BASE]})
    updated = api(f"git/refs/heads/{BRANCH}", "PATCH", {"sha": commit["sha"], "force": False})
    print(json.dumps({"branch": BRANCH, "commit": commit["sha"], "ref_sha": updated["object"]["sha"], "files": len(entries)}))


if __name__ == "__main__":
    main()
