"""
Response Pydantic models for API endpoints.
"""

from enum import Enum
from typing import Any, Dict, List, Literal, Optional, Tuple
from uuid import uuid4

from pydantic import BaseModel, Field, model_validator

from .isl_metadata import ISLResponseMetadata
from .metadata import ResponseMetadata
from .shared import (
    ConfidenceInterval,
    ConfidenceLevel,
    ConflictSeverity,
    ExplanationMetadata,
    ImportanceLevel,
    RobustnessLevel,
    SensitivityRange,
    UncertaintyLevel,
    ValidationIssueType,
    ValidationStatus,
)


class ErrorCode(str, Enum):
    """
    ISL-specific error codes following Olumi platform standard.

    All codes use ISL_ prefix for clarity in multi-service debugging.
    """

    # DAG Structure Errors
    INVALID_DAG = "ISL_INVALID_DAG"
    DAG_CYCLIC = "ISL_DAG_CYCLIC"
    DAG_EMPTY = "ISL_DAG_EMPTY"
    DAG_DISCONNECTED = "ISL_DAG_DISCONNECTED"
    NODE_NOT_FOUND = "ISL_NODE_NOT_FOUND"

    # Model Errors
    INVALID_MODEL = "ISL_INVALID_MODEL"
    INVALID_EQUATION = "ISL_INVALID_EQUATION"
    INVALID_DISTRIBUTION = "ISL_INVALID_DISTRIBUTION"
    MISSING_VARIABLE = "ISL_MISSING_VARIABLE"

    # Validation Errors
    VALIDATION_ERROR = "ISL_VALIDATION_ERROR"
    CAUSAL_NOT_IDENTIFIABLE = "ISL_CAUSAL_NOT_IDENTIFIABLE"
    NO_ADJUSTMENT_SET = "ISL_NO_ADJUSTMENT_SET"
    UNMEASURED_CONFOUNDING = "ISL_UNMEASURED_CONFOUNDING"

    # Computation Errors
    COMPUTATION_ERROR = "ISL_COMPUTATION_ERROR"
    Y0_ERROR = "ISL_Y0_ERROR"
    FACET_ERROR = "ISL_FACET_ERROR"
    MONTE_CARLO_ERROR = "ISL_MONTE_CARLO_ERROR"
    CONVERGENCE_ERROR = "ISL_CONVERGENCE_ERROR"

    # Input Errors
    INVALID_INPUT = "ISL_INVALID_INPUT"
    INVALID_INTERVENTION = "ISL_INVALID_INTERVENTION"
    INVALID_PROBABILITY = "ISL_INVALID_PROBABILITY"
    INVALID_CONFIDENCE_LEVEL = "ISL_INVALID_CONFIDENCE_LEVEL"
    BATCH_SIZE_EXCEEDED = "ISL_BATCH_SIZE_EXCEEDED"
    REQUEST_TOO_LARGE = "ISL_REQUEST_TOO_LARGE"

    # Authentication Errors
    UNAUTHORIZED = "ISL_UNAUTHORIZED"

    # Resource Errors
    TIMEOUT = "ISL_TIMEOUT"
    MEMORY_LIMIT = "ISL_MEMORY_LIMIT"
    RATE_LIMIT_EXCEEDED = "ISL_RATE_LIMIT_EXCEEDED"
    SERVICE_UNAVAILABLE = "ISL_SERVICE_UNAVAILABLE"

    # Cache Errors
    CACHE_ERROR = "ISL_CACHE_ERROR"
    REDIS_ERROR = "ISL_REDIS_ERROR"

    # Withdrawn-capability refusals (ROADMAP 2.704).
    # Served as a typed 501 by src/api/withdrawn.py for routes whose published
    # numbers were fabricated rather than computed. Distinct from every code
    # above: those describe a request that failed, this describes a capability
    # that was never honestly implemented and will not be retried into working.
    CAPABILITY_WITHDRAWN = "ISL_CAPABILITY_WITHDRAWN"


class RecoveryHints(BaseModel):
    """Recovery hints for error resolution."""

    hints: List[str] = Field(..., description="List of actionable hints")
    suggestion: str = Field(..., description="Primary suggestion")
    example: Optional[str] = Field(default=None, description="Example fix")


class ErrorResponse(BaseModel):
    """
    Olumi Error Response (v1.0) - ISL Implementation.

    Follows the canonical error schema for all Olumi services.
    See platform error schema standard for full specification.
    """

    # Domain-specific fields (ISL defines these)
    code: str = Field(..., description="Error code (e.g., 'ISL_INVALID_DAG')")
    message: str = Field(..., description="Human-readable error message")
    reason: Optional[str] = Field(
        default=None, description="Fine-grained reason code for the error"
    )

    # Service-specific details (optional)
    recovery: Optional[RecoveryHints] = Field(
        default=None, description="Recovery suggestions and hints"
    )

    # ISL domain-specific fields
    validation_failures: Optional[List[str]] = Field(
        default=None, description="List of validation failures (ISL-specific)"
    )
    node_count: Optional[int] = Field(
        default=None, description="Number of nodes in DAG (for structure errors)"
    )
    edge_count: Optional[int] = Field(
        default=None, description="Number of edges in DAG (for structure errors)"
    )
    missing_nodes: Optional[List[str]] = Field(
        default=None, description="List of missing nodes referenced in equations"
    )
    attempted_methods: Optional[List[str]] = Field(
        default=None, description="Identification methods attempted (for validation errors)"
    )

    # Platform-required fields (all services MUST include)
    retryable: bool = Field(..., description="Can client retry this request?")
    source: str = Field(default="isl", description="Service that generated error")
    request_id: str = Field(
        default_factory=lambda: f"req_{uuid4().hex[:16]}",
        description="Request ID for correlation (from X-Request-Id header)",
    )
    degraded: Optional[bool] = Field(default=False, description="Result is partial/incomplete")

    model_config = {
        "json_schema_extra": {
            "examples": [
                {
                    "title": "DAG Structure Error",
                    "value": {
                        "code": "ISL_DAG_CYCLIC",
                        "reason": "cycle_detected",
                        "message": "DAG contains cycles and cannot be processed",
                        "recovery": {
                            "hints": [
                                "Check for circular dependencies in your model",
                                "Use a DAG visualization tool to identify cycles",
                            ],
                            "suggestion": "Remove edges that create cycles",
                            "example": "If A→B→C→A exists, remove one edge",
                        },
                        "validation_failures": [
                            "Cycle: Price → Revenue → CustomerSatisfaction → Price"
                        ],
                        "node_count": 5,
                        "edge_count": 6,
                        "retryable": False,
                        "source": "isl",
                        "request_id": "req_abc123def456",
                        "degraded": False,
                    },
                },
                {
                    "title": "Validation Error",
                    "value": {
                        "code": "ISL_CAUSAL_NOT_IDENTIFIABLE",
                        "reason": "unmeasured_confounding",
                        "message": "Causal effect cannot be identified",
                        "recovery": {
                            "hints": [
                                "Add measured confounders to the model",
                                "Consider using instrumental variables",
                                "Explore front-door criterion",
                            ],
                            "suggestion": "Measure and include confounding variables",
                        },
                        "attempted_methods": ["backdoor", "front_door", "do_calculus"],
                        "retryable": False,
                        "source": "isl",
                        "request_id": "req_xyz789",
                        "degraded": False,
                    },
                },
                {
                    "title": "Timeout Error",
                    "value": {
                        "code": "ISL_TIMEOUT",
                        "message": "Computation exceeded time budget",
                        "recovery": {
                            "hints": [
                                "Simplify your causal model",
                                "Reduce Monte Carlo iterations",
                            ],
                            "suggestion": "Retry with a simpler model",
                        },
                        "retryable": True,
                        "source": "isl",
                        "request_id": "req_timeout123",
                        "degraded": False,
                    },
                },
            ]
        }
    }


class ValidationIssue(BaseModel):
    """Issue identified during causal validation."""

    type: ValidationIssueType = Field(..., description="Type of validation issue")
    description: str = Field(..., description="Description of the issue")
    affected_nodes: List[str] = Field(..., description="Nodes affected by this issue")
    suggested_action: str = Field(..., description="How to resolve the issue")

    model_config = {
        "json_schema_extra": {
            "example": {
                "type": "missing_connection",
                "description": "CustomerAcquisition may confound the Price-Revenue relationship",
                "affected_nodes": ["CustomerAcquisition", "Price", "Revenue"],
                "suggested_action": "Clarify: Does CustomerAcquisition affect Price?",
            }
        }
    }


class AssumptionDetail(BaseModel):
    """
    Individual assumption required for causal identification.

    Provides structured information about each assumption, including
    its type, description, and criticality.
    """

    type: str = Field(
        ..., description="Assumption type (e.g., 'no_unmeasured_confounding', 'positivity')"
    )
    description: str = Field(..., description="Human-readable explanation of the assumption")
    critical: bool = Field(
        ..., description="Whether this assumption is critical for identification"
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "type": "no_unmeasured_confounding",
                "description": "No unmeasured confounders after adjusting for adjustment set",
                "critical": True,
            }
        }
    }


class AlternativeMethod(BaseModel):
    """
    Alternative identification method assessment.

    Documents whether alternative methods (backdoor, front-door, IV, do-calculus)
    are applicable and why.
    """

    method: str = Field(
        ..., description="Method name (e.g., 'backdoor', 'front_door', 'instrumental_variables')"
    )
    applicable: bool = Field(..., description="Whether this method is applicable to the problem")
    reason: str = Field(..., description="Why the method is or is not applicable")

    model_config = {
        "json_schema_extra": {
            "example": {
                "method": "front_door",
                "applicable": False,
                "reason": "No mediator set completely captures causal pathway",
            }
        }
    }


class ConditionalIndependence(BaseModel):
    """
    Conditional independence assumption.

    Represents an assumption that X ⊥ Y | Z (X is independent of Y given Z).
    """

    variable_a: str = Field(..., description="First variable")
    variable_b: str = Field(..., description="Second variable")
    conditioning_set: List[str] = Field(
        default_factory=list, description="Variables to condition on"
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "variable_a": "Revenue",
                "variable_b": "Competitors",
                "conditioning_set": ["Brand"],
            }
        }
    }


class SuggestionAction(BaseModel):
    """
    Specific action to implement a suggestion.

    Contains the concrete graph modifications or assumptions needed.
    """

    # For add_mediator/add_confounder
    add_node: Optional[str] = Field(default=None, description="Node to add to the graph")
    add_edges: Optional[List[Tuple[str, str]]] = Field(
        default=None, description="Edges to add (list of [from, to] pairs)"
    )

    # For reverse_edge
    reverse_edge: Optional[Tuple[str, str]] = Field(
        default=None, description="Edge to reverse ([from, to] pair)"
    )

    # For remove_edge
    remove_edge: Optional[Tuple[str, str]] = Field(
        default=None, description="Edge to remove ([from, to] pair)"
    )

    # For conditional independence
    assume_independence: Optional[ConditionalIndependence] = Field(
        default=None, description="Conditional independence assumption to make"
    )

    model_config = {
        "json_schema_extra": {
            "examples": [
                {
                    "title": "Add Confounder",
                    "value": {
                        "add_node": "Competitors",
                        "add_edges": [["Competitors", "Price"], ["Competitors", "Revenue"]],
                    },
                },
                {"title": "Reverse Edge", "value": {"reverse_edge": ["A", "B"]}},
            ]
        }
    }


class ValidationSuggestion(BaseModel):
    """
    Actionable suggestion for making a non-identifiable DAG identifiable.

    Provides specific, algorithmic guidance on how to modify the causal graph
    or make additional assumptions to achieve identification.
    """

    type: str = Field(
        ...,
        description="Suggestion type: add_mediator, add_confounder, reverse_edge, add_conditional_independence, remove_edge",
    )
    description: str = Field(..., description="Plain English description of the suggestion")
    technical_detail: str = Field(..., description="Precise causal graph operation or assumption")
    priority: str = Field(..., description="Priority level: critical, recommended, optional")
    action: SuggestionAction = Field(..., description="Specific action to take")

    model_config = {
        "json_schema_extra": {
            "examples": [
                {
                    "title": "Add Confounder",
                    "value": {
                        "type": "add_confounder",
                        "description": "Measure competitor activity to control confounding",
                        "technical_detail": "Add Competitors node to block backdoor path: Price ← Competitors → Revenue",
                        "priority": "critical",
                        "action": {
                            "add_node": "Competitors",
                            "add_edges": [["Competitors", "Price"], ["Competitors", "Revenue"]],
                        },
                    },
                },
                {
                    "title": "Add Mediator",
                    "value": {
                        "type": "add_mediator",
                        "description": "Add CustomerSentiment to model the causal mechanism",
                        "technical_detail": "Replace Price→Revenue with Price→CustomerSentiment→Revenue",
                        "priority": "recommended",
                        "action": {
                            "add_node": "CustomerSentiment",
                            "add_edges": [
                                ["Price", "CustomerSentiment"],
                                ["CustomerSentiment", "Revenue"],
                            ],
                        },
                    },
                },
            ]
        }
    }


class CausalValidationResponse(BaseModel):
    """
    Enhanced response model for causal validation endpoint.

    Provides comprehensive Y₀-powered identifiability analysis including:
    - Identification method used (backdoor, front-door, IV, do-calculus)
    - Adjustment sets and identification formula
    - Structured assumptions with criticality
    - Alternative methods considered
    - Structured failure diagnosis when non-identifiable
    - Graceful degradation with fallback assessment
    """

    status: ValidationStatus = Field(..., description="Validation status")

    # Enhanced identifiable case fields
    method: Optional[str] = Field(
        default=None,
        description="Identification method used: backdoor, front_door, instrumental_variables, do_calculus",
    )
    adjustment_sets: Optional[List[List[str]]] = Field(
        default=None,
        description="Valid adjustment sets for causal identification",
    )
    minimal_set: Optional[List[str]] = Field(
        default=None,
        description="Minimal sufficient adjustment set",
    )
    identification_formula: Optional[str] = Field(
        default=None, description="Human-readable identification formula"
    )
    structured_assumptions: Optional[List[AssumptionDetail]] = Field(
        default=None, description="Required assumptions for valid identification (structured)"
    )
    alternative_methods: Optional[List[AlternativeMethod]] = Field(
        default=None, description="Alternative identification methods considered"
    )
    backdoor_paths: Optional[List[str]] = Field(
        default=None,
        description="Backdoor paths that create confounding",
    )

    # Enhanced non-identifiable case fields
    reason: Optional[str] = Field(
        default=None,
        description="Why identification failed (e.g., 'no_causal_path', 'unmeasured_confounding', 'selection_bias')",
    )
    suggestions: Optional[List[ValidationSuggestion]] = Field(
        default=None, description="Structured, actionable suggestions to achieve identifiability"
    )
    legacy_suggestions: Optional[List[str]] = Field(
        default=None,
        description="Legacy string suggestions (deprecated, use 'suggestions' instead)",
    )
    attempted_methods: Optional[List[str]] = Field(
        default=None, description="Methods attempted during identification"
    )
    issues: Optional[List[ValidationIssue]] = Field(
        default=None,
        description="Issues preventing identification (legacy compatibility)",
    )

    # Degraded mode fields
    fallback_assessment: Optional[Dict[str, Any]] = Field(
        default=None, description="Best-effort assessment when Y₀ fails"
    )

    # Always present
    confidence: ConfidenceLevel = Field(..., description="Confidence in the analysis")
    explanation: ExplanationMetadata = Field(..., description="Explanation metadata")

    # Metadata for determinism and reproducibility
    metadata: Optional[ResponseMetadata] = Field(
        default=None, description="Metadata for determinism verification", alias="_metadata"
    )

    model_config = {
        "populate_by_name": True,
        "json_schema_extra": {
            "examples": [
                {
                    "title": "Identifiable (Backdoor)",
                    "value": {
                        "status": "identifiable",
                        "method": "backdoor",
                        "adjustment_sets": [["Brand"], ["Brand", "CustomerAcquisition"]],
                        "minimal_set": ["Brand"],
                        "identification_formula": "P(revenue|do(price)) = Σ_Brand P(revenue|price, Brand) P(Brand)",
                        "structured_assumptions": [
                            {
                                "type": "no_unmeasured_confounding",
                                "description": "No unmeasured confounders after adjusting for Brand",
                                "critical": True,
                            },
                            {
                                "type": "positivity",
                                "description": "All price values possible at all Brand levels",
                                "critical": True,
                            },
                        ],
                        "alternative_methods": [
                            {
                                "method": "backdoor",
                                "applicable": True,
                                "reason": "Valid adjustment set exists",
                            },
                            {
                                "method": "front_door",
                                "applicable": False,
                                "reason": "No mediator set completely captures pathway",
                            },
                        ],
                        "backdoor_paths": ["Price ← Brand → Revenue"],
                        "confidence": "high",
                        "explanation": {
                            "summary": "Effect is identifiable by controlling for Brand",
                            "reasoning": "Brand influences both Price and Revenue, creating confounding. Controlling for Brand blocks the backdoor path.",
                            "technical_basis": "Backdoor criterion satisfied with adjustment set {Brand}",
                            "assumptions": [
                                "No unmeasured confounding",
                                "Correct causal structure",
                            ],
                        },
                    },
                },
                {
                    "title": "Non-Identifiable",
                    "value": {
                        "status": "cannot_identify",
                        "reason": "unmeasured_confounding",
                        "suggestions": [
                            "Add measured confounders to the model",
                            "Consider using instrumental variables if available",
                            "Explore front-door criterion with full mediation",
                        ],
                        "attempted_methods": ["backdoor", "front_door", "do_calculus"],
                        "confidence": "high",
                        "explanation": {
                            "summary": "Effect cannot be identified due to unmeasured confounding",
                            "reasoning": "Backdoor paths exist but no valid adjustment set found with measured variables.",
                            "technical_basis": "No identification formula available",
                            "assumptions": ["DAG structure correct"],
                        },
                    },
                },
            ]
        }
    }


class ScenarioDescription(BaseModel):
    """Description of the counterfactual scenario."""

    intervention: Dict[str, float] = Field(..., description="Intervention values")
    outcome: str = Field(..., description="Outcome variable")
    context: Optional[Dict[str, float]] = Field(
        default=None,
        description="Observed context",
    )


class PredictionResults(BaseModel):
    """Prediction results for counterfactual analysis."""

    point_estimate: float = Field(..., description="Most likely outcome value")
    confidence_interval: ConfidenceInterval = Field(
        ...,
        description="Confidence interval for prediction",
    )
    sensitivity_range: SensitivityRange = Field(
        ...,
        description="Range of plausible outcomes",
    )


class UncertaintyBreakdown(BaseModel):
    """Overall uncertainty of the counterfactual outcome.

    A3 (2026-07-22): the per-factor `sources` list is OMITTED — it reported each
    exogenous input's OWN variance as its "impact" on the outcome, a
    leverage-blind fabrication whose ranking inverted the true sensitivity. Only
    the honest overall level (from the OUTCOME distribution) is emitted.
    """

    overall: UncertaintyLevel = Field(..., description="Overall uncertainty level")


class CounterfactualResponse(BaseModel):
    """Response model for counterfactual analysis endpoint.

    A3 (2026-07-22): the `robustness` block is OMITTED — its "critical
    assumptions" reported a flat abs(baseline*0.15) "perturbation" and a score
    that was a constant function of the baseline sign; it neither parsed nor
    perturbed the structural equations, so it implemented none of its label. A
    real assumption-sensitivity analysis is a modeling roadmap item.
    """

    scenario: ScenarioDescription = Field(..., description="Scenario description")
    prediction: PredictionResults = Field(..., description="Prediction results")
    uncertainty: UncertaintyBreakdown = Field(..., description="Uncertainty breakdown")
    explanation: ExplanationMetadata = Field(..., description="Explanation metadata")

    # Metadata for determinism and reproducibility
    metadata: Optional[ResponseMetadata] = Field(
        default=None, description="Metadata for determinism verification", alias="_metadata"
    )

    model_config = {
        "populate_by_name": True,
        "json_schema_extra": {
            "example": {
                "scenario": {"intervention": {"Price": 15}, "outcome": "Revenue"},
                "prediction": {
                    "point_estimate": 51000,
                    "confidence_interval": {"lower": 45000, "upper": 55000},
                    "sensitivity_range": {
                        "optimistic": 62000,
                        "pessimistic": 38000,
                        "explanation": "Range accounts for competitive effects",
                    },
                },
                "uncertainty": {
                    "overall": "medium",
                },
                "explanation": {
                    "summary": "Revenue likely increases by £45k-£55k",
                    "reasoning": "Price increase drives growth...",
                    "technical_basis": "FACET region-based analysis",
                    "assumptions": ["Structural equations correct"],
                },
            }
        }
    }


class CommonGround(BaseModel):
    """Common ground among team perspectives."""

    shared_goals: List[str] = Field(..., description="Goals shared by all roles")
    shared_constraints: List[str] = Field(..., description="Constraints shared by all roles")
    agreement_level: float = Field(..., description="Agreement percentage (0-100)")


class Tradeoff(BaseModel):
    """A tradeoff for a specific role."""

    role: str = Field(..., description="Role making the tradeoff")
    gives: str = Field(..., description="What this role compromises on")
    gets: str = Field(..., description="What this role gains")


class AlignedOption(BaseModel):
    """An option with alignment analysis."""

    option: str = Field(..., description="Option ID")
    satisfies_roles: List[str] = Field(..., description="Roles satisfied by this option")
    satisfaction_score: float = Field(..., description="Overall satisfaction (0-100)")
    tradeoffs: List[Tradeoff] = Field(..., description="Tradeoffs for each role")


class Conflict(BaseModel):
    """A conflict between team perspectives."""

    between: List[str] = Field(..., description="Roles in conflict")
    about: str = Field(..., description="What the conflict is about")
    severity: ConflictSeverity = Field(..., description="Conflict severity")
    suggestion: str = Field(..., description="Potential resolution")


class Recommendation(BaseModel):
    """Recommendation for team alignment."""

    top_option: str = Field(..., description="Recommended option ID")
    rationale: str = Field(..., description="Why this option is recommended")
    confidence: ConfidenceLevel = Field(..., description="Confidence in recommendation")
    next_steps: List[str] = Field(..., description="Suggested next steps")


class TeamAlignmentResponse(BaseModel):
    """Response model for team alignment endpoint."""

    common_ground: CommonGround = Field(..., description="Shared goals and constraints")
    aligned_options: List[AlignedOption] = Field(..., description="Options with alignment scores")
    conflicts: List[Conflict] = Field(..., description="Identified conflicts")
    recommendation: Recommendation = Field(..., description="Top recommendation")
    explanation: ExplanationMetadata = Field(..., description="Explanation metadata")

    # Metadata for determinism and reproducibility
    metadata: Optional[ResponseMetadata] = Field(
        default=None, description="Metadata for determinism verification", alias="_metadata"
    )

    model_config = {
        "populate_by_name": True,
        "json_schema_extra": {
            "example": {
                "common_ground": {
                    "shared_goals": ["Deliver value to users", "Meet Q4 deadline"],
                    "shared_constraints": ["Limited budget"],
                    "agreement_level": 72,
                },
                "aligned_options": [
                    {
                        "option": "option_b",
                        "satisfies_roles": ["PM", "Designer", "Engineer"],
                        "satisfaction_score": 85,
                        "tradeoffs": [],
                    }
                ],
                "conflicts": [],
                "recommendation": {
                    "top_option": "option_b",
                    "rationale": "Balances all priorities",
                    "confidence": "high",
                    "next_steps": ["Define MVP scope"],
                },
                "explanation": {
                    "summary": "Team can align on polished feature set",
                    "reasoning": "All roles value quality...",
                    "technical_basis": "Overlap analysis with priority weighting",
                    "assumptions": ["Priorities accurate"],
                },
            }
        }
    }


class ImpactAssessment(BaseModel):
    """Impact of an assumption being wrong."""

    if_wrong: float = Field(..., description="Absolute change in result if assumption wrong")
    percentage: float = Field(..., description="Percentage of total variance explained")


class AssumptionAnalysis(BaseModel):
    """Analysis of a single assumption."""

    name: str = Field(..., description="Assumption name")
    current_value: Any = Field(..., description="Current assumed value")
    importance: ImportanceLevel = Field(..., description="Importance level")
    impact: ImpactAssessment = Field(..., description="Impact assessment")
    confidence: ConfidenceLevel = Field(..., description="Confidence in assumption")
    evidence: str = Field(..., description="Evidence for this assumption")
    recommendation: str = Field(..., description="Recommended action")


class Breakpoint(BaseModel):
    """A breakpoint where conclusion changes."""

    assumption: str = Field(..., description="Assumption name")
    threshold: str = Field(..., description="Threshold where conclusion flips")


class RobustnessScore(BaseModel):
    """Overall robustness score for sensitivity analysis."""

    overall: RobustnessLevel = Field(..., description="Overall robustness level")
    summary: str = Field(..., description="Summary of robustness")
    breakpoints: List[Breakpoint] = Field(..., description="Critical breakpoints")


class ConclusionStatement(BaseModel):
    """Conclusion statement for sensitivity analysis."""

    statement: str = Field(..., description="The conclusion being tested")
    base_case: float = Field(..., description="Base case result value")


class SensitivityAnalysisResponse(BaseModel):
    """Response model for sensitivity analysis endpoint."""

    conclusion: ConclusionStatement = Field(..., description="Conclusion being tested")
    assumptions: List[AssumptionAnalysis] = Field(..., description="Analyzed assumptions")
    robustness: RobustnessScore = Field(..., description="Overall robustness")
    explanation: ExplanationMetadata = Field(..., description="Explanation metadata")

    # Metadata for determinism and reproducibility
    metadata: Optional[ResponseMetadata] = Field(
        default=None, description="Metadata for determinism verification", alias="_metadata"
    )

    model_config = {
        "populate_by_name": True,
        "json_schema_extra": {
            "example": {
                "conclusion": {
                    "statement": "Revenue increases by £45k-£55k per month",
                    "base_case": 51000,
                },
                "assumptions": [
                    {
                        "name": "Price sensitivity",
                        "current_value": 0.5,
                        "importance": "critical",
                        "impact": {"if_wrong": 15000, "percentage": 58},
                        "confidence": "medium",
                        "evidence": "Historical data",
                        "recommendation": "Validate with A/B test",
                    }
                ],
                "robustness": {
                    "overall": "moderate",
                    "summary": "Holds unless price sensitivity substantially different",
                    "breakpoints": [
                        {
                            "assumption": "Price sensitivity",
                            "threshold": "If sensitivity > 0.75, impact becomes negative",
                        }
                    ],
                },
                "explanation": {
                    "summary": "Moderately robust with one critical assumption",
                    "reasoning": "Depends on price sensitivity...",
                    "technical_basis": "One-at-a-time sensitivity analysis",
                    "assumptions": ["Assumptions independent"],
                },
            }
        }
    }


class ComputeAdmissionInfo(BaseModel):
    """Compute-admission capability advertised on /health (Codex F8).

    Lets a planning consumer (PLoT) size requests against ISL's LIVE admission
    ceiling and formula instead of hand-mirroring the numbers. Every value is
    read from the same ISL module constants the admission gate and request model
    enforce (src.services.robustness_analyzer_v2 / src.constants), so the
    advertisement can never drift from enforcement. Consumers MUST version-guard
    on complexity_formula_version and fall back conservatively on an unknown
    version (the formula SHAPE is shared; only the numbers are advertised).

    SUFFICIENCY CONTRACT (ROADMAP 2.260 step 3): between them `weights`,
    `formula_parameters` and `caps` carry EVERY number the cost formula uses
    that a consumer cannot derive from its own request, so a consumer holding
    this block plus its own request can reproduce the price exactly for the
    advertised formula shape. Enforced mechanically by
    tests/unit/test_admission_calibration.py::TestAdvertisementSufficiency,
    which reimplements the formula from these values alone and asserts
    term-by-term equality.

    `weights` is EXACT-SET-COUPLED to the formula version for consumers that
    validate it (PLoT keys an expected key set by complexity_formula_version and
    treats an unexpected key as skew), which is why per-term structural
    parameters live in the SIBLING `formula_parameters` object instead of being
    added to `weights` — see build_compute_admission.__doc__ for the full
    rationale and for the drift-alarm this trades away.
    """

    max_cost_units: int = Field(
        ..., description="Admission ceiling in cost units (env-resolved; ISL_MAX_COST_UNITS)."
    )
    complexity_formula_version: str = Field(
        ..., description="Version tag of the weighted cost formula shape."
    )
    weights: Dict[str, int] = Field(
        ..., description="Per-phase structural coefficients used by the cost formula."
    )
    formula_parameters: Dict[str, Dict[str, int]] = Field(
        default_factory=dict,
        description=(
            "Per-term structural parameters, keyed by the term name the cost "
            "breakdown uses (e.g. factor_flips.max_candidates, "
            "sensitivity.subsample_cap). These are the bounds a term's own loop "
            "applies, as distinct from the per-phase coefficients in `weights`; "
            "a consumer needs both to reproduce the price. Sibling of `weights` "
            "so it can grow without disturbing consumers that couple to the "
            "`weights` key set."
        ),
    )
    caps: Dict[str, int] = Field(
        ...,
        description="Request-shape ceilings enforced by the request model (max nodes/edges/etc).",
    )


class HealthResponse(BaseModel):
    """Response model for health check endpoint."""

    status: str = Field(default="healthy", description="Service status")
    version: str = Field(..., description="Service version")
    build: str = Field(default="unknown", description="Short Git commit SHA (7 chars)")
    build_full: Optional[str] = Field(default=None, description="Full Git commit SHA (40 chars)")
    timestamp: str = Field(..., description="Current timestamp")
    config_fingerprint: Optional[str] = Field(
        default=None, description="Config fingerprint for determinism verification"
    )
    compute_admission: Optional[ComputeAdmissionInfo] = Field(
        default=None,
        description="Weighted compute-admission capability (ceiling, formula version, "
        "weights, caps) for planning consumers (Codex F8).",
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "status": "healthy",
                "version": "1.0.0",
                "build": "f380662",
                "build_full": "f380662abc123def456789012345678901234567",
                "timestamp": "2025-01-15T10:30:00Z",
            }
        }
    }


class InterventionChange(BaseModel):
    """A single variable change in an intervention."""

    variable: str = Field(..., description="Variable name")
    from_value: float = Field(..., description="Current value")
    to_value: float = Field(..., description="Proposed new value")
    delta: float = Field(..., description="Absolute change (to_value - from_value)")
    relative_change: float = Field(..., description="Relative change as percentage")
    unit: Optional[str] = Field(default=None, description="Optional unit of measurement")

    model_config = {
        "json_schema_extra": {
            "example": {
                "variable": "Price",
                "from_value": 40,
                "to_value": 45,
                "delta": 5,
                "relative_change": 12.5,
                "unit": "£",
            }
        }
    }


class MinimalIntervention(BaseModel):
    """A minimal intervention achieving target outcome."""

    rank: int = Field(..., description="Rank by optimization criterion (1 = best)", ge=1)
    changes: Dict[str, InterventionChange] = Field(
        ...,
        description="Variables to change and their values",
    )
    expected_outcome: Dict[str, float] = Field(
        ...,
        description="Expected outcome values after intervention",
    )
    confidence_interval: Dict[str, ConfidenceInterval] = Field(
        ...,
        description="Confidence intervals for each outcome",
    )
    feasibility: float = Field(
        ...,
        description="Feasibility score (0-1, higher = more feasible)",
        ge=0,
        le=1,
    )
    cost_estimate: str = Field(
        ...,
        description="Cost estimate: low, medium, high",
    )
    robustness: RobustnessLevel = Field(
        ...,
        description="Robustness level from FACET analysis",
    )
    robustness_score: float = Field(
        ...,
        description="Numerical robustness score (0-1)",
        ge=0,
        le=1,
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "rank": 1,
                "changes": {
                    "Price": {
                        "variable": "Price",
                        "from_value": 40,
                        "to_value": 45,
                        "delta": 5,
                        "relative_change": 12.5,
                        "unit": "£",
                    }
                },
                "expected_outcome": {"Revenue": 51000},
                "confidence_interval": {
                    "Revenue": {"lower": 48000, "upper": 54000, "confidence_level": 0.95}
                },
                "feasibility": 0.95,
                "cost_estimate": "low",
                "robustness": "robust",
                "robustness_score": 0.85,
            }
        }
    }


class InterventionComparison(BaseModel):
    """Comparison of multiple interventions."""

    best_by_cost: int = Field(..., description="Rank of best intervention by cost")
    best_by_robustness: int = Field(..., description="Rank of best intervention by robustness")
    best_by_feasibility: int = Field(..., description="Rank of best intervention by feasibility")
    synergies: str = Field(..., description="Analysis of combining multiple interventions")
    tradeoffs: str = Field(..., description="Key tradeoffs between interventions")

    model_config = {
        "json_schema_extra": {
            "example": {
                "best_by_cost": 1,
                "best_by_robustness": 1,
                "best_by_feasibility": 2,
                "synergies": "Combining Price and Marketing changes yields diminishing returns (expected gain: £52k vs £51k individually)",
                "tradeoffs": "Price increase is cheaper but less robust; Marketing spend is more robust but costlier",
            }
        }
    }


class ContrastiveExplanationResponse(BaseModel):
    """Response model for contrastive explanation endpoint."""

    minimal_interventions: List[MinimalIntervention] = Field(
        ...,
        description="Minimal interventions ranked by optimization criterion",
    )
    comparison: InterventionComparison = Field(
        ...,
        description="Comparison of interventions",
    )
    explanation: ExplanationMetadata = Field(
        ...,
        description="Plain English explanation of recommendations",
    )

    # Metadata for determinism and reproducibility
    metadata: Optional[ResponseMetadata] = Field(
        default=None, description="Metadata for determinism verification", alias="_metadata"
    )

    model_config = {
        "populate_by_name": True,
        "json_schema_extra": {
            "example": {
                "minimal_interventions": [
                    {
                        "rank": 1,
                        "changes": {
                            "Price": {
                                "variable": "Price",
                                "from_value": 40,
                                "to_value": 45,
                                "delta": 5,
                                "relative_change": 12.5,
                                "unit": "£",
                            }
                        },
                        "expected_outcome": {"Revenue": 51000},
                        "confidence_interval": {
                            "Revenue": {"lower": 48000, "upper": 54000, "confidence_level": 0.95}
                        },
                        "feasibility": 0.95,
                        "cost_estimate": "low",
                        "robustness": "robust",
                        "robustness_score": 0.85,
                    }
                ],
                "comparison": {
                    "best_by_cost": 1,
                    "best_by_robustness": 1,
                    "best_by_feasibility": 1,
                    "synergies": "Single intervention sufficient for target",
                    "tradeoffs": "No significant tradeoffs",
                },
                "explanation": {
                    "summary": "Increase Price from £40 to £45 to achieve target revenue",
                    "reasoning": "Price has strong causal effect on Revenue. A 12.5% increase yields expected £11k revenue gain.",
                    "technical_basis": "Binary search with FACET robustness verification",
                    "assumptions": ["Price elasticity remains constant", "No competitive response"],
                },
            }
        }
    }


class ScenarioResult(BaseModel):
    """Result for a single counterfactual scenario."""

    scenario_id: str = Field(..., description="Scenario identifier")
    intervention: Dict[str, float] = Field(..., description="Intervention values")
    label: Optional[str] = Field(default=None, description="Human-readable label")
    prediction: PredictionResults = Field(..., description="Prediction results")
    uncertainty: UncertaintyBreakdown = Field(..., description="Uncertainty breakdown")
    # A3 (2026-07-22): the per-scenario `robustness` block is OMITTED — it was the
    # same fabricated CounterfactualEngine robustness (constant score + flat
    # perturbation) this remediation removed from the single /counterfactual
    # response.

    model_config = {
        "json_schema_extra": {
            "example": {
                "scenario_id": "aggressive_pricing",
                "intervention": {"Price": 50},
                "label": "10% price increase",
                "prediction": {
                    "point_estimate": 35000,
                    "confidence_interval": {"lower": 33000, "upper": 37000},
                    "sensitivity_range": {
                        "optimistic": 38000,
                        "pessimistic": 32000,
                        "explanation": "Range accounts for uncertainty",
                    },
                },
                "uncertainty": {
                    "overall": "medium",
                },
            }
        }
    }


class PairwiseInteraction(BaseModel):
    """Pairwise interaction between two variables."""

    variables: Tuple[str, str] = Field(..., description="Pair of variables")
    type: str = Field(..., description="Interaction type: synergistic, antagonistic, or additive")
    effect_size: float = Field(..., description="Interaction effect size in outcome units")
    significance: float = Field(..., description="Significance score (0-1)", ge=0, le=1)
    explanation: str = Field(..., description="Plain English explanation")

    model_config = {
        "json_schema_extra": {
            "example": {
                "variables": ["Price", "Quality"],
                "type": "synergistic",
                "effect_size": 5000,
                "significance": 0.85,
                "explanation": "Price and Quality interact synergistically: combined effect (£55k) exceeds sum of individual effects (£48k)",
            }
        }
    }


class InteractionAnalysis(BaseModel):
    """Analysis of variable interactions."""

    pairwise: List[PairwiseInteraction] = Field(
        default_factory=list,
        description="Pairwise interactions detected",
    )
    summary: str = Field(..., description="Plain English summary of interactions")

    model_config = {
        "json_schema_extra": {
            "example": {
                "pairwise": [
                    {
                        "variables": ["Price", "Quality"],
                        "type": "synergistic",
                        "effect_size": 5000,
                        "significance": 0.85,
                        "explanation": "Price and Quality interact synergistically",
                    }
                ],
                "summary": "Strong synergistic interaction between Price and Quality (£5k additional gain)",
            }
        }
    }


class ScenarioComparison(BaseModel):
    """Comparison of multiple scenarios.

    A3 (2026-07-22): `most_robust` is OMITTED — it ranked scenarios by the
    fabricated counterfactual robustness score (a constant), so the "most robust"
    verdict was meaningless. Outcome-based ranking (best_outcome / ranking /
    marginal_gains) is retained.
    """

    best_outcome: str = Field(..., description="Scenario ID with best outcome")
    marginal_gains: Dict[str, float] = Field(
        ...,
        description="Marginal uplift of each scenario vs baseline",
    )
    ranking: List[str] = Field(..., description="Scenarios ranked by outcome")

    model_config = {
        "json_schema_extra": {
            "example": {
                "best_outcome": "combined",
                "marginal_gains": {
                    "increase": 5000,
                    "combined": 12000,
                },
                "ranking": ["combined", "increase", "baseline"],
            }
        }
    }


class BatchCounterfactualResponse(BaseModel):
    """Response model for batch counterfactual analysis."""

    scenarios: List[ScenarioResult] = Field(
        ...,
        description="Results for each scenario",
    )
    interactions: Optional[InteractionAnalysis] = Field(
        default=None,
        description="Interaction analysis (if enabled)",
    )
    comparison: ScenarioComparison = Field(
        ...,
        description="Comparison across scenarios",
    )
    explanation: ExplanationMetadata = Field(
        ...,
        description="Overall explanation",
    )

    # Metadata for determinism and reproducibility
    metadata: Optional[ResponseMetadata] = Field(
        default=None, description="Metadata for determinism verification", alias="_metadata"
    )

    model_config = {
        "populate_by_name": True,
        "json_schema_extra": {
            "example": {
                "scenarios": [
                    {
                        "scenario_id": "baseline",
                        "intervention": {"Price": 40},
                        "label": "Current pricing",
                        "prediction": {
                            "point_estimate": 30000,
                            "confidence_interval": {"lower": 28000, "upper": 32000},
                        },
                    },
                    {
                        "scenario_id": "increase",
                        "intervention": {"Price": 50},
                        "label": "10% increase",
                        "prediction": {
                            "point_estimate": 35000,
                            "confidence_interval": {"lower": 33000, "upper": 37000},
                        },
                    },
                ],
                "interactions": {
                    "pairwise": [],
                    "summary": "No significant interactions detected",
                },
                "comparison": {
                    "best_outcome": "increase",
                    "marginal_gains": {"increase": 5000},
                    "ranking": ["increase", "baseline"],
                },
                "explanation": {
                    "summary": "Price increase yields £5k marginal gain",
                    "reasoning": "10% price increase produces consistent revenue uplift across scenarios",
                    "technical_basis": "Batch counterfactual analysis with interaction detection",
                    "assumptions": ["Structural equations correct", "No external shocks"],
                },
            }
        }
    }


class TransportAssumption(BaseModel):
    """
    Individual assumption required for transportability.

    Documents what must hold for causal effects to transport
    from source domain to target domain.
    """

    type: str = Field(
        ...,
        description="Assumption type (e.g., 'same_mechanism', 'no_selection_bias', 'common_support')",
    )
    description: str = Field(..., description="Human-readable explanation of the assumption")
    critical: bool = Field(
        ..., description="Whether this assumption is critical for transportability"
    )
    testable: bool = Field(..., description="Whether this assumption can be empirically tested")

    model_config = {
        "json_schema_extra": {
            "example": {
                "type": "same_mechanism",
                "description": "The causal mechanism Price→Revenue is the same in both UK and Germany",
                "critical": True,
                "testable": False,
            }
        }
    }


class TransportabilityResponse(BaseModel):
    """
    Response model for transportability analysis endpoint.

    Indicates whether causal effects identified in source domain
    can be transported to target domain, along with required
    assumptions and robustness assessment.
    """

    transportable: bool = Field(..., description="Whether the causal effect can be transported")
    method: Optional[str] = Field(
        default=None,
        description="Transportability method used (e.g., 'selection_diagram', 'weighting', 'direct')",
    )
    formula: Optional[str] = Field(default=None, description="Transport formula if transportable")
    required_assumptions: List[TransportAssumption] = Field(
        default_factory=list, description="Assumptions required for valid transport"
    )
    robustness: str = Field(..., description="Robustness assessment: robust, moderate, fragile")
    reason: Optional[str] = Field(default=None, description="Reason if not transportable")
    suggestions: Optional[List[str]] = Field(
        default=None, description="Suggestions if not transportable"
    )
    confidence: ConfidenceLevel = Field(
        ..., description="Confidence in transportability assessment"
    )
    explanation: ExplanationMetadata = Field(..., description="Plain English explanation")

    # Metadata for determinism and reproducibility
    metadata: Optional[ResponseMetadata] = Field(
        default=None, description="Metadata for determinism verification", alias="_metadata"
    )

    model_config = {
        "populate_by_name": True,
        "json_schema_extra": {
            "examples": [
                {
                    "title": "Transportable Effect",
                    "value": {
                        "transportable": True,
                        "method": "selection_diagram",
                        "formula": "P_target(revenue|do(price)) = Σ_S P_source(revenue|price,S) P_target(S)",
                        "required_assumptions": [
                            {
                                "type": "same_mechanism",
                                "description": "Price→Revenue mechanism identical in UK and Germany",
                                "critical": True,
                                "testable": False,
                            },
                            {
                                "type": "no_selection_bias",
                                "description": "Selection into domains doesn't affect mechanism",
                                "critical": True,
                                "testable": True,
                            },
                        ],
                        "robustness": "moderate",
                        "confidence": "medium",
                        "explanation": {
                            "summary": "Effect can be transported by adjusting for domain selection",
                            "reasoning": "Selection diagram shows effect is transportable via re-weighting by domain-specific covariates",
                            "technical_basis": "Y₀ transportability algorithm with selection nodes",
                            "assumptions": [
                                "Same causal mechanism",
                                "Measured selection variables",
                            ],
                        },
                    },
                },
                {
                    "title": "Non-Transportable Effect",
                    "value": {
                        "transportable": False,
                        "reason": "different_mechanisms",
                        "suggestions": [
                            "Collect data on market structure differences",
                            "Test if price elasticity differs between domains",
                            "Consider stratified analysis by market segment",
                        ],
                        "robustness": "fragile",
                        "confidence": "high",
                        "explanation": {
                            "summary": "Effect cannot be transported due to mechanism differences",
                            "reasoning": "Regulatory differences between UK and Germany alter Price→Revenue mechanism",
                            "technical_basis": "Y₀ transportability algorithm - no valid transport formula found",
                            "assumptions": [
                                "DAG structure correct",
                                "Selection variables complete",
                            ],
                        },
                    },
                },
            ]
        }
    }


class ConformalInterval(BaseModel):
    """
    Conformal prediction interval with guaranteed coverage.

    Provides lower and upper bounds with finite-sample validity.
    """

    lower_bound: Dict[str, float] = Field(
        ...,
        description="Lower bound of prediction interval for each outcome variable",
    )
    upper_bound: Dict[str, float] = Field(
        ...,
        description="Upper bound of prediction interval for each outcome variable",
    )
    point_estimate: Dict[str, float] = Field(
        ...,
        description="Point estimate for each outcome variable",
    )
    interval_width: Dict[str, float] = Field(
        ...,
        description="Width of prediction interval (upper - lower)",
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "lower_bound": {"Revenue": 48000},
                "upper_bound": {"Revenue": 56000},
                "point_estimate": {"Revenue": 52000},
                "interval_width": {"Revenue": 8000},
            }
        }
    }


class CoverageGuarantee(BaseModel):
    """
    Coverage guarantee for conformal prediction.

    Documents the theoretical guarantee that the true value
    will fall within the interval with specified probability.
    """

    nominal_coverage: float = Field(
        ...,
        description="Requested coverage level (e.g., 0.95)",
    )
    guaranteed_coverage: float = Field(
        ...,
        description="Provable coverage level accounting for finite samples",
    )
    finite_sample_valid: bool = Field(
        ...,
        description="Whether guarantee holds for finite samples (always True for conformal)",
    )
    assumptions: List[str] = Field(
        ...,
        description="Assumptions required for coverage guarantee",
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "nominal_coverage": 0.95,
                "guaranteed_coverage": 0.9474,
                "finite_sample_valid": True,
                "assumptions": ["Exchangeability of calibration and test points"],
            }
        }
    }


class CalibrationMetrics(BaseModel):
    """
    Metrics assessing calibration quality.

    Provides statistics about the calibration set and
    how well it covers the prediction space.
    """

    calibration_size: int = Field(
        ...,
        description="Number of calibration samples",
    )
    residual_statistics: Dict[str, float] = Field(
        ...,
        description="Statistics of calibration residuals (mean, std, median, iqr)",
    )
    interval_adaptivity: float = Field(
        ...,
        description="How much intervals adapt to local uncertainty (higher = more adaptive)",
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "calibration_size": 50,
                "residual_statistics": {
                    "mean": 2500,
                    "std": 1200,
                    "median": 2300,
                    "iqr": 1500,
                },
                "interval_adaptivity": 0.48,
            }
        }
    }


class ComparisonMetrics(BaseModel):
    """
    Comparison of conformal vs standard Monte Carlo intervals.

    Shows how conformal intervals differ from traditional
    uncertainty quantification approaches.
    """

    monte_carlo_interval: Dict[str, ConfidenceInterval] = Field(
        ...,
        description="Standard Monte Carlo confidence intervals",
    )
    conformal_interval: Dict[str, tuple[float, float]] = Field(
        ...,
        description="Conformal prediction intervals",
    )
    width_ratio: Dict[str, float] = Field(
        ...,
        description="Ratio of conformal width to Monte Carlo width",
    )
    interpretation: str = Field(
        ...,
        description="Plain English interpretation of the comparison",
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "monte_carlo_interval": {
                    "Revenue": {"lower": 49000, "upper": 55000, "confidence_level": 0.95}
                },
                "conformal_interval": {"Revenue": [48000, 56000]},
                "width_ratio": {"Revenue": 1.33},
                "interpretation": "Conformal interval is 33% wider, providing more honest uncertainty quantification with finite-sample guarantees",
            }
        }
    }


class ConformalCounterfactualResponse(BaseModel):
    """
    Response model for conformal counterfactual prediction.

    Provides prediction intervals with finite-sample valid
    coverage guarantees, calibration quality metrics, and
    comparison to standard methods.
    """

    prediction_interval: ConformalInterval = Field(
        ...,
        description="Conformal prediction interval",
    )
    coverage_guarantee: CoverageGuarantee = Field(
        ...,
        description="Coverage guarantee details",
    )
    calibration_quality: CalibrationMetrics = Field(
        ...,
        description="Quality metrics for calibration set",
    )
    comparison_to_standard: ComparisonMetrics = Field(
        ...,
        description="Comparison to standard Monte Carlo intervals",
    )
    explanation: ExplanationMetadata = Field(
        ...,
        description="Plain English explanation",
    )

    # Metadata for determinism and reproducibility
    metadata: Optional[ResponseMetadata] = Field(
        default=None,
        description="Metadata for determinism verification",
        alias="_metadata",
    )

    model_config = {
        "populate_by_name": True,
        "json_schema_extra": {
            "example": {
                "prediction_interval": {
                    "lower_bound": {"Revenue": 48000},
                    "upper_bound": {"Revenue": 56000},
                    "point_estimate": {"Revenue": 52000},
                    "interval_width": {"Revenue": 8000},
                },
                "coverage_guarantee": {
                    "nominal_coverage": 0.95,
                    "guaranteed_coverage": 0.9474,
                    "finite_sample_valid": True,
                    "assumptions": ["Exchangeability of calibration and test points"],
                },
                "calibration_quality": {
                    "calibration_size": 50,
                    "residual_statistics": {
                        "mean": 2500,
                        "std": 1200,
                        "median": 2300,
                        "iqr": 1500,
                    },
                    "interval_adaptivity": 0.48,
                },
                "comparison_to_standard": {
                    "monte_carlo_interval": {
                        "Revenue": {"lower": 49000, "upper": 55000, "confidence_level": 0.95}
                    },
                    "conformal_interval": {"Revenue": [48000, 56000]},
                    "width_ratio": {"Revenue": 1.33},
                    "interpretation": "Conformal interval is 33% wider",
                },
                "explanation": {
                    "summary": "Conformal prediction provides 94.7% guaranteed coverage",
                    "reasoning": "Using split conformal with 50 calibration points",
                    "technical_basis": "Finite-sample conformal prediction (Vovk et al. 2005)",
                    "assumptions": ["Exchangeability between calibration and test data"],
                },
            }
        }
    }


class AdjustmentStrategyDetail(BaseModel):
    """
    Complete adjustment strategy for identifiability.

    Specifies exactly what nodes/edges to add to make a non-identifiable
    DAG identifiable.
    """

    strategy_type: str = Field(
        ..., description="Strategy type: backdoor, frontdoor, or instrumental"
    )
    nodes_to_add: List[str] = Field(..., description="Nodes that need to be added/measured")
    edges_to_add: List[Tuple[str, str]] = Field(..., description="Edges to add to the DAG")
    explanation: str = Field(..., description="Plain English explanation of the strategy")
    theoretical_basis: str = Field(
        ..., description="Theoretical justification (e.g., Pearl's backdoor criterion)"
    )
    expected_identifiability: float = Field(
        ...,
        description="Confidence that this strategy achieves identifiability (0-1)",
        ge=0,
        le=1,
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "strategy_type": "backdoor",
                "nodes_to_add": ["Competitors"],
                "edges_to_add": [
                    ["Competitors", "Price"],
                    ["Competitors", "Revenue"],
                ],
                "explanation": "Add and measure Competitors variable, then control for it to block backdoor paths",
                "theoretical_basis": "Pearl's backdoor criterion",
                "expected_identifiability": 0.9,
            }
        }
    }


class PathAnalysisDetail(BaseModel):
    """
    Analysis of causal paths in a DAG.

    Identifies backdoor paths, frontdoor paths, and critical nodes.
    """

    backdoor_paths: List[List[str]] = Field(
        ..., description="Backdoor paths from treatment to outcome"
    )
    frontdoor_paths: List[List[str]] = Field(
        ..., description="Directed paths from treatment to outcome"
    )
    blocked_paths: List[List[str]] = Field(
        ..., description="Paths that are already blocked by colliders"
    )
    critical_nodes: List[str] = Field(
        ..., description="Nodes that block multiple paths if controlled"
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "backdoor_paths": [["Price", "Competitors", "Revenue"]],
                "frontdoor_paths": [["Price", "Revenue"]],
                "blocked_paths": [],
                "critical_nodes": ["Competitors"],
            }
        }
    }


class ValidationStrategyResponse(BaseModel):
    """
    Response model for enhanced validation strategies.

    Provides complete adjustment strategies and path analysis.
    """

    strategies: List[AdjustmentStrategyDetail] = Field(
        ..., description="Adjustment strategies ranked by expected success"
    )
    path_analysis: PathAnalysisDetail = Field(..., description="Comprehensive path analysis")
    explanation: ExplanationMetadata = Field(..., description="Plain English explanation")

    # Metadata for determinism and reproducibility
    metadata: Optional[ResponseMetadata] = Field(
        default=None,
        description="Metadata for determinism verification",
        alias="_metadata",
    )

    model_config = {
        "populate_by_name": True,
        "json_schema_extra": {
            "example": {
                "strategies": [
                    {
                        "strategy_type": "backdoor",
                        "nodes_to_add": [],
                        "edges_to_add": [],
                        "explanation": "Control for existing variable Competitors to block backdoor paths",
                        "theoretical_basis": "Pearl's backdoor criterion",
                        "expected_identifiability": 0.9,
                    }
                ],
                "path_analysis": {
                    "backdoor_paths": [["Price", "Competitors", "Revenue"]],
                    "frontdoor_paths": [["Price", "Revenue"]],
                    "blocked_paths": [],
                    "critical_nodes": ["Competitors"],
                },
                "explanation": {
                    "summary": "Effect is identifiable by controlling for Competitors",
                    "reasoning": "Competitors creates a backdoor path between Price and Revenue",
                    "technical_basis": "Backdoor path analysis and adjustment set identification",
                    "assumptions": ["DAG structure is correct"],
                },
            }
        }
    }


class DiscoveredDAG(BaseModel):
    """A discovered DAG structure with confidence score."""

    nodes: List[str] = Field(..., description="Variable names")
    edges: List[Tuple[str, str]] = Field(..., description="Directed edges")
    confidence: float = Field(
        ...,
        description="Confidence in this structure (0-1)",
        ge=0,
        le=1,
    )
    method: str = Field(..., description="Discovery method used (correlation, knowledge, hybrid)")

    model_config = {
        "json_schema_extra": {
            "example": {
                "nodes": ["Price", "Quality", "Revenue"],
                "edges": [
                    ["Price", "Revenue"],
                    ["Quality", "Revenue"],
                    ["Quality", "Price"],
                ],
                "confidence": 0.75,
                "method": "correlation",
            }
        }
    }


class DiscoveryResponse(BaseModel):
    """
    Response model for causal discovery.

    Returns discovered DAG structures with confidence scores.
    """

    discovered_dags: List[DiscoveredDAG] = Field(
        ..., description="Discovered DAG structures ranked by confidence"
    )
    explanation: ExplanationMetadata = Field(..., description="Plain English explanation")

    # Metadata for determinism and reproducibility
    metadata: Optional[ResponseMetadata] = Field(
        default=None,
        description="Metadata for determinism verification",
        alias="_metadata",
    )

    model_config = {
        "populate_by_name": True,
        "json_schema_extra": {
            "example": {
                "discovered_dags": [
                    {
                        "nodes": ["Price", "Quality", "Revenue"],
                        "edges": [
                            ["Price", "Revenue"],
                            ["Quality", "Revenue"],
                        ],
                        "confidence": 0.85,
                        "method": "correlation",
                    }
                ],
                "explanation": {
                    "summary": "Discovered DAG structure from data with 85% confidence",
                    "reasoning": "Strong correlations between Price→Revenue (0.82) and Quality→Revenue (0.75)",
                    "technical_basis": "Correlation-based structure learning with threshold 0.3",
                    "assumptions": ["Linear relationships", "No hidden confounders"],
                },
            }
        }
    }


class RecommendedExperimentDetail(BaseModel):
    """
    Recommended experiment specification.

    Specifies intervention values, expected outcomes, and information gain.
    """

    intervention: Dict[str, float] = Field(..., description="Recommended intervention values")
    expected_outcome: Dict[str, float] = Field(..., description="Expected outcome values")
    expected_information_gain: float = Field(
        ...,
        description="Expected information gain from this experiment (0-1)",
        ge=0,
        le=1,
    )
    cost_estimate: float = Field(..., description="Estimated cost of the experiment")
    rationale: str = Field(..., description="Plain English rationale for this recommendation")
    exploration_vs_exploitation: float = Field(
        ...,
        description="Exploration vs exploitation score (0=exploit, 1=explore)",
        ge=0,
        le=1,
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "intervention": {"Price": 55},
                "expected_outcome": {"Revenue": 38000},
                "expected_information_gain": 0.75,
                "cost_estimate": 10000,
                "rationale": "Explore: Test Price=55 to learn more (high information gain: 0.75)",
                "exploration_vs_exploitation": 0.8,
            }
        }
    }


class ExperimentRecommendationResponse(BaseModel):
    """
    Response model for experiment recommendation.

    Provides recommended next experiment using Thompson sampling.
    """

    recommendation: RecommendedExperimentDetail = Field(
        ..., description="Recommended next experiment"
    )
    explanation: ExplanationMetadata = Field(..., description="Plain English explanation")

    # Metadata for determinism and reproducibility
    metadata: Optional[ResponseMetadata] = Field(
        default=None,
        description="Metadata for determinism verification",
        alias="_metadata",
    )

    model_config = {
        "populate_by_name": True,
        "json_schema_extra": {
            "example": {
                "recommendation": {
                    "intervention": {"Price": 55},
                    "expected_outcome": {"Revenue": 38000},
                    "expected_information_gain": 0.75,
                    "cost_estimate": 10000,
                    "rationale": "Explore: Test Price=55 to learn more (high information gain: 0.75)",
                    "exploration_vs_exploitation": 0.8,
                },
                "explanation": {
                    "summary": "Recommend testing Price=55 to maximize learning",
                    "reasoning": "This intervention has high information gain (0.75) and explores undersampled region",
                    "technical_basis": "Thompson sampling with 100 posterior samples",
                    "assumptions": [
                        "Parameter beliefs accurate",
                        "Cost-benefit tradeoff acceptable",
                    ],
                },
            }
        }
    }


# ============================================================================
# CEE Enhancement Endpoints (Phase 0) - Response Models
# ============================================================================


class AssumptionSensitivity(BaseModel):
    """Sensitivity information for a single assumption/variable."""

    variable: str = Field(..., description="Node ID or variable name", max_length=100)
    sensitivity: float = Field(
        ..., description="Sensitivity score (0-1), higher = more sensitive", ge=0.0, le=1.0
    )
    impact: str = Field(..., description="Description of impact", max_length=500)

    model_config = {
        "json_schema_extra": {
            "example": {
                "variable": "n_market_size",
                "sensitivity": 0.92,
                "impact": "10% change in market size estimate leads to 25% swing in projected ROI",
            }
        }
    }


class SensitivityDetailedResponse(BaseModel):
    """Response model for detailed sensitivity analysis."""

    assumptions: List[AssumptionSensitivity] = Field(
        ..., description="List of assumptions with sensitivity analysis"
    )
    metadata: Optional["ISLResponseMetadata"] = Field(
        None, description="Request metadata for tracing and monitoring"
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "assumptions": [
                    {
                        "variable": "n_market_size",
                        "sensitivity": 0.92,
                        "impact": "10% change in market size estimate leads to 25% swing in projected ROI",
                    },
                    {
                        "variable": "n_adoption_rate",
                        "sensitivity": 0.78,
                        "impact": "Adoption rate uncertainty accounts for most outcome variance",
                    },
                ]
            }
        }
    }


class ContrastiveAlternative(BaseModel):
    """Single contrastive alternative suggestion."""

    change: str = Field(..., description="What to change", max_length=1000)
    outcome_diff: str = Field(..., description="How outcome would differ", max_length=1000)
    feasibility: float = Field(..., description="Implementation feasibility (0-1)", ge=0.0, le=1.0)

    model_config = {
        "json_schema_extra": {
            "example": {
                "change": "Increase initial marketing budget by 40%",
                "outcome_diff": "Would increase market penetration from 12% to 18% in Q1",
                "feasibility": 0.85,
            }
        }
    }


class ContrastiveResponse(BaseModel):
    """Response model for contrastive explanation."""

    alternatives: List[ContrastiveAlternative] = Field(
        ..., description="List of actionable alternatives"
    )
    metadata: Optional["ISLResponseMetadata"] = Field(
        None, description="Request metadata for tracing and monitoring"
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "alternatives": [
                    {
                        "change": "Increase initial marketing budget by 40%",
                        "outcome_diff": "Would increase market penetration from 12% to 18% in Q1",
                        "feasibility": 0.85,
                    },
                    {
                        "change": "Partner with established distributor",
                        "outcome_diff": "Would reduce time-to-market by 3 months but increase costs 15%",
                        "feasibility": 0.60,
                    },
                ]
            }
        }
    }


class ConformalResponse(BaseModel):
    """Response model for conformal prediction."""

    prediction_interval: List[float] = Field(
        ..., description="Numeric bounds [lower, upper]", min_length=2, max_length=2
    )
    confidence_level: float = Field(..., description="Confidence level (0-1)", ge=0.0, le=1.0)
    uncertainty_source: str = Field(..., description="Main source of uncertainty", max_length=500)
    metadata: Optional["ISLResponseMetadata"] = Field(
        None, description="Request metadata for tracing and monitoring"
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "prediction_interval": [45000, 78000],
                "confidence_level": 0.90,
                "uncertainty_source": "Market demand volatility and competitor response timing",
            }
        }
    }


class ValidationImprovement(BaseModel):
    """Single model improvement suggestion."""

    type: str = Field(
        ...,
        description="Category (e.g., data_collection, model_structure, sensitivity_test)",
        max_length=100,
    )
    description: str = Field(..., description="What to do", max_length=1000)
    priority: str = Field(..., description="Implementation priority", pattern="^(high|medium|low)$")

    model_config = {
        "json_schema_extra": {
            "example": {
                "type": "data_collection",
                "description": "Gather historical adoption data from 3-5 comparable product launches to calibrate adoption rate assumptions",
                "priority": "high",
            }
        }
    }


class ValidationStrategiesResponse(BaseModel):
    """Response model for validation strategies."""

    suggested_improvements: List[ValidationImprovement] = Field(
        ..., description="List of suggested model improvements"
    )
    metadata: Optional["ISLResponseMetadata"] = Field(
        None, description="Request metadata for tracing and monitoring"
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "suggested_improvements": [
                    {
                        "type": "data_collection",
                        "description": "Gather historical adoption data from 3-5 comparable product launches to calibrate adoption rate assumptions",
                        "priority": "high",
                    },
                    {
                        "type": "model_structure",
                        "description": "Add explicit node for competitor response to capture strategic interaction effects",
                        "priority": "medium",
                    },
                    {
                        "type": "sensitivity_test",
                        "description": "Test model robustness by varying market size estimate ±20%",
                        "priority": "low",
                    },
                ]
            }
        }
    }


# ============================================================================
# Parameter Recommendation Endpoint - Response Models
# ============================================================================


class ParameterRecommendation(BaseModel):
    """Single parameter recommendation with range and rationale."""

    parameter: str = Field(
        ..., description="Parameter name (e.g., 'n_decision_to_n_outcome_weight')", max_length=200
    )
    parameter_type: str = Field(..., description="Type of parameter", pattern="^(weight|belief)$")
    current_value: Optional[float] = Field(
        default=None, description="Current parameter value (if provided in request)"
    )
    recommended_range: List[float] = Field(
        ..., description="Recommended range [min, max]", min_length=2, max_length=2
    )
    recommended_typical: float = Field(..., description="Typical/center value of recommended range")
    rationale: str = Field(
        ..., description="Explanation of why this range is recommended", max_length=500
    )
    importance: float = Field(
        ..., description="Parameter importance (0-1, from sensitivity analysis)", ge=0.0, le=1.0
    )
    confidence: str = Field(
        ..., description="Confidence in recommendation", pattern="^(high|medium|low)$"
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "parameter": "n_decision_to_n_outcome_weight",
                "parameter_type": "weight",
                "current_value": 2.0,
                "recommended_range": [1.2, 1.8],
                "recommended_typical": 1.5,
                "rationale": "Critical path edge connecting decision to outcome - requires strong causal influence",
                "importance": 0.92,
                "confidence": "high",
            }
        }
    }


class ParameterRecommendationResponse(BaseModel):
    """Response model for parameter recommendation endpoint."""

    recommendations: List[ParameterRecommendation] = Field(
        ..., description="List of parameter recommendations sorted by importance"
    )
    graph_characteristics: Dict[str, Any] = Field(..., description="Metadata about graph structure")

    model_config = {
        "json_schema_extra": {
            "example": {
                "recommendations": [
                    {
                        "parameter": "n_decision_to_n_outcome_weight",
                        "parameter_type": "weight",
                        "current_value": 2.0,
                        "recommended_range": [1.2, 1.8],
                        "recommended_typical": 1.5,
                        "rationale": "Critical path edge connecting decision to outcome - requires strong causal influence",
                        "importance": 0.92,
                        "confidence": "high",
                    },
                    {
                        "parameter": "n_decision_belief",
                        "parameter_type": "belief",
                        "current_value": 0.8,
                        "recommended_range": [0.75, 0.95],
                        "recommended_typical": 0.85,
                        "rationale": "Treatment node - high certainty recommended for robust analysis",
                        "importance": 0.78,
                        "confidence": "high",
                    },
                ],
                "graph_characteristics": {
                    "num_critical_edges": 3,
                    "max_path_length": 4,
                    "avg_centrality": 0.42,
                },
            }
        }
    }


# ============================================================================
# Dominance Detection Endpoint - Response Models
# ============================================================================


class DominanceRelation(BaseModel):
    """Information about a dominated option."""

    dominated_option_id: str = Field(..., description="ID of the option that is dominated")
    dominated_option_label: str = Field(..., description="Label of the option that is dominated")
    dominated_by: List[str] = Field(..., description="List of option IDs that dominate this option")
    degree: int = Field(..., description="Number of options that dominate this option", ge=0)

    model_config = {
        "json_schema_extra": {
            "example": {
                "dominated_option_id": "opt_b",
                "dominated_option_label": "Option B: Conservative Growth",
                "dominated_by": ["opt_c", "opt_a"],
                "degree": 2,
            }
        }
    }


class DominanceResponse(BaseModel):
    """Response model for dominance detection endpoint."""

    dominated: List[DominanceRelation] = Field(
        ..., description="Options that are dominated by others (sorted by degree, descending)"
    )
    non_dominated_ids: List[str] = Field(
        ..., description="Option IDs that are not dominated (Pareto frontier)"
    )
    total_options: int = Field(..., description="Total number of options analyzed", ge=2)
    frontier_size: int = Field(..., description="Number of options on Pareto frontier", ge=1)
    metadata: Optional["ISLResponseMetadata"] = Field(
        None, description="Request metadata for tracing and monitoring"
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "dominated": [
                    {
                        "dominated_option_id": "opt_b",
                        "dominated_option_label": "Option B: Conservative Growth",
                        "dominated_by": ["opt_c"],
                        "degree": 1,
                    }
                ],
                "non_dominated_ids": ["opt_a", "opt_c"],
                "total_options": 3,
                "frontier_size": 2,
                "metadata": {
                    "request_id": "req_abc123",
                    "computation_time_ms": 2.5,
                    "isl_version": "2.0",
                    "algorithm": "pairwise_dominance",
                    "cache_hit": False,
                },
            }
        }
    }


# ============================================================================
# Pareto Frontier Endpoint - Response Models
# ============================================================================


class ParetoFrontierOption(BaseModel):
    """Single option on the Pareto frontier with scores."""

    option_id: str = Field(..., description="Option identifier")
    option_label: str = Field(..., description="Human-readable option label")
    scores: Dict[str, float] = Field(..., description="Normalized scores by criterion_id")

    model_config = {
        "json_schema_extra": {
            "example": {
                "option_id": "opt_a",
                "option_label": "Option A: Aggressive Growth",
                "scores": {"revenue": 0.90, "risk": 0.40, "timeline": 0.70},
            }
        }
    }


class ParetoResponse(BaseModel):
    """Response model for Pareto frontier endpoint."""

    frontier: List[ParetoFrontierOption] = Field(
        ..., description="Options on the Pareto frontier (non-dominated options)"
    )
    dominated: List[DominanceRelation] = Field(
        ..., description="Options that are dominated (sorted by degree, descending)"
    )
    frontier_size: int = Field(..., description="Number of options on Pareto frontier", ge=1)
    total_options: int = Field(..., description="Total number of options analyzed", ge=2)
    frontier_truncated: bool = Field(
        default=False, description="True if frontier was truncated due to max_frontier_size limit"
    )
    metadata: Optional["ISLResponseMetadata"] = Field(
        None, description="Request metadata for tracing and monitoring"
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "frontier": [
                    {
                        "option_id": "opt_a",
                        "option_label": "Option A: Aggressive Growth",
                        "scores": {"revenue": 0.90, "risk": 0.40, "timeline": 0.70},
                    },
                    {
                        "option_id": "opt_c",
                        "option_label": "Option C: Balanced Approach",
                        "scores": {"revenue": 0.75, "risk": 0.75, "timeline": 0.80},
                    },
                ],
                "dominated": [
                    {
                        "dominated_option_id": "opt_b",
                        "dominated_option_label": "Option B: Conservative Growth",
                        "dominated_by": ["opt_c"],
                        "degree": 1,
                    }
                ],
                "frontier_size": 2,
                "total_options": 3,
                "frontier_truncated": False,
                "metadata": {
                    "request_id": "req_abc123",
                    "computation_time_ms": 2.8,
                    "isl_version": "2.0",
                    "algorithm": "skyline_pareto",
                    "cache_hit": False,
                },
            }
        }
    }


# ============================================================================
# Multi-Criteria Aggregation Endpoint - Response Models
# ============================================================================


class AggregatedRanking(BaseModel):
    """Aggregated ranking for a single option."""

    option_id: str = Field(..., description="Option identifier")
    option_label: str = Field(..., description="Human-readable option label")
    rank: int = Field(..., description="Rank (1-based, 1 = best)", ge=1)
    aggregated_score: float = Field(
        ..., description="Final aggregated score (0-100 scale)", ge=0.0, le=100.0
    )
    scores_by_criterion: Dict[str, float] = Field(
        ..., description="Normalized scores (0-1) used in aggregation by criterion_id"
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "option_id": "opt_a",
                "option_label": "Option A: Aggressive Growth",
                "rank": 1,
                "aggregated_score": 72.5,
                "scores_by_criterion": {"revenue": 0.85, "risk": 0.40, "timeline": 0.70},
            }
        }
    }


class TradeOff(BaseModel):
    """Trade-off between two options."""

    option_a_id: str = Field(..., description="First option ID")
    option_a_label: str = Field(..., description="First option label")
    option_b_id: str = Field(..., description="Second option ID")
    option_b_label: str = Field(..., description="Second option label")
    a_better_on: List[str] = Field(..., description="Criterion IDs where option A scores higher")
    b_better_on: List[str] = Field(..., description="Criterion IDs where option B scores higher")
    max_difference: float = Field(
        ..., description="Largest score gap across criteria", ge=0.0, le=1.0
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "option_a_id": "opt_a",
                "option_a_label": "Option A: Aggressive Growth",
                "option_b_id": "opt_b",
                "option_b_label": "Option B: Conservative Growth",
                "a_better_on": ["revenue", "timeline"],
                "b_better_on": ["risk"],
                "max_difference": 0.45,
            }
        }
    }


class ValidationWarning(BaseModel):
    """Warning about validation actions taken."""

    code: str = Field(
        ...,
        description="Warning code",
        pattern="^(WEIGHTS_NORMALIZED|OPTION_MISMATCH|SCORE_CLAMPED|MISSING_CRITERION)$",
    )
    message: str = Field(..., description="Human-readable warning message", max_length=500)
    affected_items: Optional[List[str]] = Field(
        None, description="IDs of affected items (options, criteria, etc.)"
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "code": "WEIGHTS_NORMALIZED",
                "message": "Weights normalized from sum=0.95 to sum=1.0",
                "affected_items": ["revenue", "risk"],
            }
        }
    }


class MultiCriteriaResponse(BaseModel):
    """Response model for multi-criteria aggregation endpoint."""

    aggregated_rankings: List[AggregatedRanking] = Field(
        ..., description="Options ranked by aggregated score (sorted best to worst)"
    )
    trade_offs: List[TradeOff] = Field(
        ..., description="Significant trade-offs between top options"
    )
    warnings: Optional[List[ValidationWarning]] = Field(
        None, description="Warnings about auto-corrections or validation issues"
    )

    # Y₀ Identifiability fields (Task: Y₀ Hard Rule)
    identifiability: Optional["IdentifiabilityInfo"] = Field(
        default=None,
        description="Identifiability analysis for the primary decision→goal effect (if graph provided)",
    )
    recommendation_status: Optional["RecommendationStatusEnum"] = Field(
        default=None, description="HARD RULE: 'actionable' if identifiable, 'exploratory' if not"
    )
    recommendation_caveat: Optional[str] = Field(
        default=None,
        description="Caveat for recommendations (required if recommendation_status is 'exploratory')",
    )

    metadata: Optional["ISLResponseMetadata"] = Field(
        None, description="Request metadata for tracing and monitoring"
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "aggregated_rankings": [
                    {
                        "option_id": "opt_a",
                        "option_label": "Option A",
                        "rank": 1,
                        "aggregated_score": 72.5,
                        "scores_by_criterion": {"revenue": 0.85, "risk": 0.40},
                    },
                    {
                        "option_id": "opt_b",
                        "option_label": "Option B",
                        "rank": 2,
                        "aggregated_score": 68.0,
                        "scores_by_criterion": {"revenue": 0.60, "risk": 0.80},
                    },
                ],
                "trade_offs": [
                    {
                        "option_a_id": "opt_a",
                        "option_a_label": "Option A",
                        "option_b_id": "opt_b",
                        "option_b_label": "Option B",
                        "a_better_on": ["revenue"],
                        "b_better_on": ["risk"],
                        "max_difference": 0.40,
                    }
                ],
                "warnings": [
                    {
                        "code": "WEIGHTS_NORMALIZED",
                        "message": "Weights normalized from sum=0.95 to sum=1.0",
                        "affected_items": ["revenue", "risk"],
                    }
                ],
                "metadata": {
                    "request_id": "req_abc123",
                    "computation_time_ms": 5.2,
                    "isl_version": "2.0",
                    "algorithm": "weighted_sum",
                    "cache_hit": False,
                },
            }
        }
    }


# ============================================================================
# Risk Adjustment Endpoint - Response Models
# ============================================================================


class AdjustedScore(BaseModel):
    """Risk-adjusted score for a single option."""

    option_id: str = Field(..., description="Option identifier")
    option_label: str = Field(..., description="Human-readable option label")
    original_score: float = Field(..., description="Original score (mean or p50)", ge=0.0, le=1.0)
    certainty_equivalent: float = Field(
        ..., description="Risk-adjusted certainty equivalent score", ge=0.0, le=1.0
    )
    adjustment: float = Field(..., description="Adjustment amount (CE - original, can be negative)")
    variance: Optional[float] = Field(
        None, description="Variance of original distribution (if mean/std_dev provided)", ge=0.0
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "option_id": "opt_aggressive",
                "option_label": "Aggressive Growth Strategy",
                "original_score": 0.80,
                "certainty_equivalent": 0.60,
                "adjustment": -0.20,
                "variance": 0.04,
            }
        }
    }


class RankingChange(BaseModel):
    """Details about ranking changes after risk adjustment."""

    option_id: str = Field(..., description="Option identifier")
    option_label: str = Field(..., description="Option label")
    original_rank: int = Field(..., description="Rank before adjustment (1-based)", ge=1)
    adjusted_rank: int = Field(..., description="Rank after adjustment (1-based)", ge=1)
    rank_change: int = Field(
        ..., description="Change in rank (positive = improved, negative = worsened)"
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "option_id": "opt_conservative",
                "option_label": "Conservative Growth Strategy",
                "original_rank": 2,
                "adjusted_rank": 1,
                "rank_change": 1,
            }
        }
    }


class RiskAdjustmentResponse(BaseModel):
    """Response model for risk adjustment endpoint."""

    adjusted_scores: List[AdjustedScore] = Field(
        ..., description="Options with risk-adjusted scores (sorted by CE, descending)"
    )
    rankings_changed: bool = Field(
        ..., description="True if rankings changed after risk adjustment"
    )
    ranking_changes: Optional[List[RankingChange]] = Field(
        None, description="Detailed ranking changes (only if rankings_changed=True)"
    )
    risk_interpretation: str = Field(
        ..., description="Plain English interpretation of risk adjustment impact", max_length=1000
    )
    metadata: Optional["ISLResponseMetadata"] = Field(
        None, description="Request metadata for tracing and monitoring"
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "adjusted_scores": [
                    {
                        "option_id": "opt_conservative",
                        "option_label": "Conservative Growth Strategy",
                        "original_score": 0.60,
                        "certainty_equivalent": 0.59,
                        "adjustment": -0.01,
                        "variance": 0.0025,
                    },
                    {
                        "option_id": "opt_aggressive",
                        "option_label": "Aggressive Growth Strategy",
                        "original_score": 0.80,
                        "certainty_equivalent": 0.60,
                        "adjustment": -0.20,
                        "variance": 0.04,
                    },
                    {
                        "option_id": "opt_balanced",
                        "option_label": "Balanced Approach",
                        "original_score": 0.70,
                        "certainty_equivalent": 0.58,
                        "adjustment": -0.12,
                        "variance": 0.0225,
                    },
                ],
                "rankings_changed": True,
                "ranking_changes": [
                    {
                        "option_id": "opt_conservative",
                        "option_label": "Conservative Growth Strategy",
                        "original_rank": 3,
                        "adjusted_rank": 1,
                        "rank_change": 2,
                    },
                    {
                        "option_id": "opt_aggressive",
                        "option_label": "Aggressive Growth Strategy",
                        "original_rank": 1,
                        "adjusted_rank": 2,
                        "rank_change": -1,
                    },
                ],
                "risk_interpretation": "Risk aversion (coefficient=2.0) significantly penalizes high-variance options. Conservative strategy moves from rank 3 to rank 1 after adjustment, while aggressive strategy drops from rank 1 to rank 2 due to high variance (0.04).",
                "metadata": {
                    "request_id": "req_risk_abc123",
                    "computation_time_ms": 1.8,
                    "isl_version": "2.0",
                    "algorithm": "mean_variance_risk_averse",
                    "cache_hit": False,
                },
            }
        }
    }


# ============================================================================
# Threshold Identification Endpoint - Response Models
# ============================================================================


class RankingThreshold(BaseModel):
    """A parameter threshold where ranking changes."""

    parameter_id: str = Field(..., description="Parameter identifier")
    parameter_label: str = Field(..., description="Parameter label")
    threshold_value: float = Field(..., description="Parameter value where ranking changes")
    ranking_before: List[str] = Field(
        ..., description="Option ranking before threshold (option_ids, best to worst)"
    )
    ranking_after: List[str] = Field(
        ..., description="Option ranking after threshold (option_ids, best to worst)"
    )
    options_affected: List[str] = Field(
        ..., description="Option IDs whose ranks changed at this threshold"
    )
    score_gap: Optional[float] = Field(
        None, description="Score difference between swapped options at threshold", ge=0.0, le=1.0
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "parameter_id": "price",
                "parameter_label": "Product Price",
                "threshold_value": 50.0,
                "ranking_before": ["opt_a", "opt_c", "opt_b"],
                "ranking_after": ["opt_b", "opt_a", "opt_c"],
                "options_affected": ["opt_a", "opt_b"],
                "score_gap": 0.05,
            }
        }
    }


class ParameterSensitivity(BaseModel):
    """Sensitivity analysis for a parameter."""

    parameter_id: str = Field(..., description="Parameter identifier")
    parameter_label: str = Field(..., description="Parameter label")
    changes_count: int = Field(
        ..., description="Number of ranking changes across parameter sweep", ge=0
    )
    most_sensitive_range: Optional[List[float]] = Field(
        None,
        description="Parameter range [min, max] where most changes occur (if any changes)",
        min_length=2,
        max_length=2,
    )
    sensitivity_score: float = Field(
        ...,
        description="Normalized sensitivity score (0-1, higher = more sensitive)",
        ge=0.0,
        le=1.0,
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "parameter_id": "price",
                "parameter_label": "Product Price",
                "changes_count": 2,
                "most_sensitive_range": [45.0, 55.0],
                "sensitivity_score": 0.85,
            }
        }
    }


class ThresholdIdentificationResponse(BaseModel):
    """Response model for threshold identification endpoint."""

    thresholds: List[RankingThreshold] = Field(
        ...,
        description="Ranking thresholds across all parameters (sorted by parameter, then value)",
    )
    sensitivity_ranking: List[ParameterSensitivity] = Field(
        ..., description="Parameters ranked by sensitivity (most sensitive first)"
    )
    total_thresholds: int = Field(
        ..., description="Total number of thresholds found across all parameters", ge=0
    )
    monotonic_parameters: List[str] = Field(
        ..., description="Parameter IDs with no ranking changes (monotonic)"
    )
    metadata: Optional["ISLResponseMetadata"] = Field(
        None, description="Request metadata for tracing and monitoring"
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "thresholds": [
                    {
                        "parameter_id": "price",
                        "parameter_label": "Product Price",
                        "threshold_value": 50.0,
                        "ranking_before": ["opt_a", "opt_c", "opt_b"],
                        "ranking_after": ["opt_b", "opt_a", "opt_c"],
                        "options_affected": ["opt_a", "opt_b"],
                        "score_gap": 0.05,
                    },
                    {
                        "parameter_id": "price",
                        "parameter_label": "Product Price",
                        "threshold_value": 60.0,
                        "ranking_before": ["opt_b", "opt_a", "opt_c"],
                        "ranking_after": ["opt_b", "opt_c", "opt_a"],
                        "options_affected": ["opt_a", "opt_c"],
                        "score_gap": 0.02,
                    },
                ],
                "sensitivity_ranking": [
                    {
                        "parameter_id": "price",
                        "parameter_label": "Product Price",
                        "changes_count": 2,
                        "most_sensitive_range": [45.0, 65.0],
                        "sensitivity_score": 1.0,
                    },
                    {
                        "parameter_id": "marketing_spend",
                        "parameter_label": "Marketing Spend",
                        "changes_count": 0,
                        "most_sensitive_range": None,
                        "sensitivity_score": 0.0,
                    },
                ],
                "total_thresholds": 2,
                "monotonic_parameters": ["marketing_spend"],
                "metadata": {
                    "request_id": "req_threshold_abc123",
                    "computation_time_ms": 3.5,
                    "isl_version": "2.0",
                    "algorithm": "sequential_ranking_comparison",
                    "cache_hit": False,
                },
            }
        }
    }


# ============================================================================
# Phase 4: Sequential Decisions & Conditional Recommendations - Response Models
# ============================================================================


class ConditionExpression(BaseModel):
    """Machine-readable condition expression."""

    parameter: str = Field(..., description="Parameter name being conditioned on")
    operator: str = Field(
        ..., description="Comparison operator", pattern="^(<|<=|>|>=|==|in_range)$"
    )
    value: Any = Field(..., description="Threshold value or range tuple for 'in_range'")

    model_config = {
        "json_schema_extra": {
            "example": {"parameter": "marketing_roi", "operator": "<", "value": 0.3}
        }
    }


class PrimaryRecommendation(BaseModel):
    """Primary recommendation for an option."""

    option_id: str = Field(..., description="Recommended option ID")
    label: str = Field(..., description="Human-readable label")
    confidence: str = Field(..., description="Confidence level", pattern="^(high|medium|low)$")
    expected_value: float = Field(..., description="Expected value of this option")

    model_config = {
        "json_schema_extra": {
            "example": {
                "option_id": "option_a",
                "label": "Aggressive Expansion",
                "confidence": "high",
                "expected_value": 75000.0,
            }
        }
    }


class ConditionalRecommendation(BaseModel):
    """A conditional recommendation that depends on parameter values."""

    condition_id: str = Field(..., description="Unique condition identifier")
    condition_type: str = Field(
        ...,
        description="Type of condition",
        pattern="^(threshold|dominance|risk_profile|scenario)$",
    )
    condition_description: str = Field(
        ..., description="Human-readable description of the condition"
    )
    condition_expression: ConditionExpression = Field(
        ..., description="Machine-readable condition expression"
    )
    triggered_recommendation: PrimaryRecommendation = Field(
        ..., description="Recommendation when condition is true"
    )
    probability_of_condition: Optional[float] = Field(
        default=None, description="Estimated probability that condition is true", ge=0.0, le=1.0
    )
    impact_magnitude: str = Field(
        ..., description="Impact magnitude if condition is true", pattern="^(high|medium|low)$"
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "condition_id": "cond_001",
                "condition_type": "threshold",
                "condition_description": "If marketing ROI drops below 0.3",
                "condition_expression": {
                    "parameter": "marketing_roi",
                    "operator": "<",
                    "value": 0.3,
                },
                "triggered_recommendation": {
                    "option_id": "option_b",
                    "label": "Conservative Growth",
                    "confidence": "medium",
                    "expected_value": 50000.0,
                },
                "probability_of_condition": 0.25,
                "impact_magnitude": "high",
            }
        }
    }


class RobustnessSummary(BaseModel):
    """Summary of recommendation robustness."""

    recommendation_stability: str = Field(
        ..., description="Overall stability classification", pattern="^(robust|moderate|fragile)$"
    )
    conditions_count: int = Field(
        ..., description="Number of conditions that could flip the recommendation", ge=0
    )
    closest_flip_point: Optional[ConditionExpression] = Field(
        default=None, description="Nearest condition that would flip the recommendation"
    )
    safety_margin: Optional[float] = Field(
        default=None, description="Distance to nearest flip point (in parameter units)"
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "recommendation_stability": "moderate",
                "conditions_count": 3,
                "closest_flip_point": {"parameter": "market_size", "operator": "<", "value": 0.75},
                "safety_margin": 0.15,
            }
        }
    }


class ConditionalRecommendResponse(BaseModel):
    """Response model for conditional recommendation endpoint."""

    schema_version: str = Field(
        default="conditional_recommend.v1", description="Schema version for this response"
    )
    primary_recommendation: PrimaryRecommendation = Field(
        ..., description="Primary (unconditional) recommendation"
    )
    conditional_recommendations: List[ConditionalRecommendation] = Field(
        ..., description="List of conditional recommendations"
    )
    robustness_summary: RobustnessSummary = Field(
        ..., description="Summary of recommendation robustness"
    )

    # Metadata for determinism and reproducibility
    metadata: Optional[ResponseMetadata] = Field(
        default=None, description="Metadata for determinism verification", alias="_metadata"
    )

    model_config = {
        "populate_by_name": True,
        "json_schema_extra": {
            "example": {
                "schema_version": "conditional_recommend.v1",
                "primary_recommendation": {
                    "option_id": "option_a",
                    "label": "Aggressive Expansion",
                    "confidence": "high",
                    "expected_value": 75000.0,
                },
                "conditional_recommendations": [
                    {
                        "condition_id": "cond_001",
                        "condition_type": "threshold",
                        "condition_description": "If marketing ROI drops below 30%",
                        "condition_expression": {
                            "parameter": "marketing_roi",
                            "operator": "<",
                            "value": 0.3,
                        },
                        "triggered_recommendation": {
                            "option_id": "option_b",
                            "label": "Conservative Growth",
                            "confidence": "medium",
                            "expected_value": 50000.0,
                        },
                        "probability_of_condition": 0.25,
                        "impact_magnitude": "high",
                    }
                ],
                "robustness_summary": {
                    "recommendation_stability": "moderate",
                    "conditions_count": 3,
                    "closest_flip_point": {
                        "parameter": "market_size",
                        "operator": "<",
                        "value": 0.75,
                    },
                    "safety_margin": 0.15,
                },
            }
        }
    }


# Sequential Decision Support Response Models


class ConditionalAction(BaseModel):
    """A conditional action in a decision rule."""

    condition: str = Field(..., description="Human-readable condition string")
    action: str = Field(..., description="Action to take if condition is met")
    expected_value_if_taken: float = Field(
        ..., description="Expected value if this action is taken"
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "condition": "If demand_signal > 0.7",
                "action": "expand",
                "expected_value_if_taken": 85000.0,
            }
        }
    }


class DecisionRule(BaseModel):
    """Conditional decision rule based on observed state."""

    default_action: str = Field(..., description="Default action if no conditions are met")
    conditional_actions: List[ConditionalAction] = Field(
        default_factory=list, description="List of conditional actions"
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "default_action": "wait",
                "conditional_actions": [
                    {
                        "condition": "If market_favorable",
                        "action": "expand",
                        "expected_value_if_taken": 85000.0,
                    },
                    {
                        "condition": "If market_unfavorable",
                        "action": "exit",
                        "expected_value_if_taken": 10000.0,
                    },
                ],
            }
        }
    }


class StagePolicy(BaseModel):
    """Optimal decision policy for a single stage.

    Exactly ONE `decision_rule`, and that is now the whole truth rather than
    half of it. The request previously accepted up to 20 `decision_nodes` per
    stage while backward induction solved the first and dropped the rest — and
    this model has no field in which the drop could have been disclosed, so a
    consumer received what read as the complete policy for the stage. Arch step
    1 (2026-07-26) closes the gap at the request boundary instead: >1 decision
    node per stage is rejected (`MULTI_DECISION_STAGE_UNSUPPORTED`), so the
    single rule below is now provably the whole policy for the stage.

    A stage with several genuinely distinct decisions needs a policy shape that
    can carry several rules. That is a modelling roadmap item; until it ships,
    the service declines such requests rather than answering them partially.
    """

    stage_index: int = Field(..., description="Stage index", ge=0)
    stage_label: str = Field(..., description="Human-readable stage label")
    decision_rule: DecisionRule = Field(
        ...,
        description="The decision rule for this stage — the complete policy for it. "
        "A stage declares at most one decision node (enforced at the request "
        "boundary), so this is never a truncation of several rules.",
    )
    contingent_on: List[str] = Field(
        default_factory=list, description="What must be observed before this stage"
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "stage_index": 1,
                "stage_label": "Pricing Decision",
                "decision_rule": {
                    "default_action": "standard_pricing",
                    "conditional_actions": [
                        {
                            "condition": "If market_favorable",
                            "action": "premium_pricing",
                            "expected_value_if_taken": 100000.0,
                        }
                    ],
                },
                "contingent_on": ["market_outcome"],
            }
        }
    }


class Policy(BaseModel):
    """Optimal policy across all stages.

    A3 (2026-07-22): `value_distribution` is OMITTED — it reported normal params
    with std = 0.2 * |expected_total_value|, a fabricated spread presented as if
    measured (backward induction is deterministic). A real policy-value
    distribution is a modeling roadmap item.
    """

    stages: List[StagePolicy] = Field(..., description="Policy for each stage")
    expected_total_value: float = Field(
        ..., description="Expected total value following this policy"
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "stages": [
                    {
                        "stage_index": 0,
                        "stage_label": "Investment",
                        "decision_rule": {"default_action": "invest", "conditional_actions": []},
                        "contingent_on": [],
                    }
                ],
                "expected_total_value": 45000.0,
            }
        }
    }


class StageOption(BaseModel):
    """Analysis of a single option at a stage."""

    option_id: str = Field(..., description="Option identifier")
    label: str = Field(..., description="Human-readable label")
    immediate_value: float = Field(..., description="Immediate payoff of choosing this option")
    continuation_value: float = Field(..., description="Expected value of future stages")
    total_value: float = Field(..., description="Total value (immediate + discounted continuation)")

    model_config = {
        "json_schema_extra": {
            "example": {
                "option_id": "invest",
                "label": "Make Investment",
                "immediate_value": -50000,
                "continuation_value": 95000,
                "total_value": 45000,
            }
        }
    }


class StageAnalysis(BaseModel):
    """Analysis for a single stage.

    A3 (2026-07-22): `information_value` was relabeled `resolved_uncertainty`
    (F4c) — the quantity is sqrt(Σ variance) of the chance nodes resolving at this
    stage (a payoff-unit magnitude of outcome dispersion), NOT a value of
    information (E[value|info] − E[value]). The old name and its "difference
    between value with and without information" claim were unsupported.
    """

    stage_index: int = Field(..., description="Stage index", ge=0)
    stage_label: str = Field(..., description="Human-readable stage label")
    options_at_stage: List[StageOption] = Field(
        ..., description="Options available at this stage with analysis"
    )
    resolved_uncertainty: float = Field(
        ...,
        description="Magnitude of outcome dispersion resolved at this stage: "
        "sqrt of the summed variance of the chance nodes that resolve here, in "
        "payoff units. This is NOT a value of information (E[value|info] − "
        "E[value]); it does not compare a with-information policy to a "
        "without-information one.",
    )
    stage_evpi: Optional[float] = Field(
        default=None,
        description="Honest per-stage expected value of perfect information, in "
        "OUTCOME (payoff) UNITS: stage_evpi = E_C[max_a Q(a | C)] − "
        "max_a E_C[Q(a)] — the expected value of perfectly resolving the chance "
        "node(s) this stage's decision faces BEFORE choosing an action, minus "
        "deciding without that information. The decide-now leg is the decision's "
        "backward-induction value (max_a E_C[Q]); the decide-after leg re-picks the "
        "best action for each realised chance outcome and averages over outcomes "
        "(E_C[max_a Q]). >= 0 by construction (Jensen), and EXACTLY 0 when one action "
        "dominates in every chance branch or the decision faces no chance node. This "
        "REPLACES the removed `optimal_waiting_value` (a discount × sqrt(Σvar) "
        "dispersion heuristic that was NOT an option value). null (JSON null) for a "
        "stage with no decision node — this endpoint does not omit None fields, "
        "matching the prior optimal_waiting_value convention. "
        "SCOPE & IDENTIFIABILITY (F1, D-23.11): stage_evpi measures the value of "
        "resolving the chance THIS stage's decision faces IMMEDIATELY (the chance "
        "node(s) directly under its actions) before choosing. Chance that sits deeper "
        "in the tree is a LATER stage's EVPI — resolved when that stage is analysed, "
        "not folded in here. So a stage whose actions face NO immediate chance has "
        "stage_evpi 0 with stage_evpi_status null (EXACT: there is no immediate "
        "uncertainty to resolve at this stage, regardless of deeper chance). When the "
        "decision DOES face immediate chance, the decide-after leg resolves it and "
        "re-chooses: this is EXACT (status null) when at most ONE action faces any "
        "reachable chance (every other action deterministic, its value coupling-"
        "invariant). It is NOT exact — stage_evpi_status='assumed_independent_coupling' "
        "with coupling_assumption='independence_across_actions' — when >=2 actions face "
        "reachable chance (one immediate, another immediate OR one level deeper): the "
        "leg then substitutes an AVERAGED value (the deeper action's unconditional Q) "
        "for its conditional value, i.e. it ASSUMES the resolved chance is independent "
        "of the other action's uncertainty. The tree supplies only the MARGINALS and "
        "does not identify that joint law (the same marginals admit same-state or "
        "opposite couplings with different EVPIs; a shared node reused under another "
        "action identifies a different value than the emitted one), so consult those "
        "two fields before reading stage_evpi as exact. "
        "RISK POSTURE: computed on the engine's "
        "risk-ADJUSTED node values, so "
        "each per-outcome choice matches the optimal policy; for "
        "risk_tolerance='neutral' this is the standard risk-neutral EVPI. The "
        "resolved chance's own variance is not re-penalised in the outer average "
        "(perfect information removes it); deeper continuations keep their risk "
        "adjustment.",
    )
    stage_evpi_status: Optional[
        Literal[
            "no_decision_node",
            "skipped_joint_space_too_large",
            "skipped_shared_chance_nodes_unsupported",
            "assumed_independent_coupling",
        ]
    ] = Field(
        default=None,
        description="Disclosure of stage_evpi's status (F-3 skip reasons + F1 "
        "identifiability). null/absent when stage_evpi is EXACT — either the stage "
        "faces NO immediate chance (EVPI 0; deeper chance is a later stage's EVPI, not "
        "this one's), or the decision faces immediate chance but at most ONE action "
        "faces any reachable chance, so resolving that single uncertainty is exact "
        "(includes a genuine EVPI of 0.0). Three null-value skip reasons: "
        "'no_decision_node' — the stage has no "
        "decision node, so there is no choice for information to inform; "
        "'skipped_joint_space_too_large' — the decide-after leg's joint enumeration "
        "(∏ of the decision's chance-child branch counts) exceeds the safety cap "
        "(4096 cells), so this AUXILIARY metric is honestly skipped rather than "
        "pinning the event loop (the exact analysis — optimal_policy, "
        "value_of_flexibility, resolved_uncertainty, options — is unaffected); "
        "'skipped_shared_chance_nodes_unsupported' (D-23.19) — the SAME chance-node "
        "id is reachable from >=2 actions' subtrees, so the graph IDENTIFIES their "
        "coupling (same id = same random variable) and the independence enumeration "
        "would contradict it (it mixes one action's realised copy against another's "
        "averaged copy of the same variable); skipped until conditional subtree "
        "re-valuation ships. One "
        "value-present disclosure: 'assumed_independent_coupling' (F1, D-23.11) — the "
        "stage faces immediate chance AND >=2 actions face DISJOINT reachable chance "
        "(one immediate, another immediate or deeper), so stage_evpi is COMPUTED "
        "but under an ASSUMED independence coupling the tree does not identify (see "
        "coupling_assumption); the value is present but is NOT exact. Lets a consumer "
        "distinguish a real 0, a null skip, and an assumption-laden value.",
    )
    coupling_assumption: Optional[Literal["independence_across_actions"]] = Field(
        default=None,
        description="F1 (D-23.11) disclosure of the cross-action coupling assumption "
        "under which stage_evpi was computed. Present EXACTLY when "
        "stage_evpi_status=='assumed_independent_coupling'; null otherwise. "
        "'independence_across_actions': the stage's decision faces immediate chance "
        "AND >=2 of its mutually-exclusive actions face a reachable chance node (one "
        "immediate, another immediate OR one level deeper), so the decide-after leg "
        "mixed one action's per-branch realised value against another action's "
        "AVERAGED value — i.e. it ASSUMED the resolved chance is independent of the "
        "other action's (possibly deeper) uncertainty. The tree identifies only the "
        "marginals, not this joint law; the assumption is one modelling choice (the "
        "same marginals admit other couplings with different EVPIs, and a shared "
        "reused node identifies a different value than the emitted one) and is "
        "disclosed here rather than silently baked into a value labelled exact.",
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "stage_index": 0,
                "stage_label": "Investment Decision",
                "options_at_stage": [
                    {
                        "option_id": "invest",
                        "label": "Make Investment",
                        "immediate_value": -50000,
                        "continuation_value": 95000,
                        "total_value": 45000,
                    },
                    {
                        "option_id": "wait",
                        "label": "Wait and See",
                        "immediate_value": 0,
                        "continuation_value": 20000,
                        "total_value": 20000,
                    },
                ],
                "resolved_uncertainty": 15000.0,
                "stage_evpi": 11220.0,
                "stage_evpi_status": None,
            }
        }
    }

    @model_validator(mode="after")
    def _status_present_iff_evpi_absent(self) -> "StageAnalysis":
        """Sibling-presence invariant (altitude Q1, F-3 + F1): fail loud in Pydantic
        if the (stage_evpi, stage_evpi_status, coupling_assumption) triple ever
        desyncs, matching decision_evpi's fail-loud altitude rather than relying on
        the tuple-return convention alone. Three disjoint, exhaustive shapes:

        * skip reason ('no_decision_node' | 'skipped_joint_space_too_large' |
          'skipped_shared_chance_nodes_unsupported' [D-23.19]):
          stage_evpi is NULL (there is no value), coupling_assumption absent;
        * 'assumed_independent_coupling' (F1, D-23.11): stage_evpi is COMPUTED but
          under an unidentified independence assumption, so it rides WITH a value AND
          a coupling_assumption naming that assumption;
        * no status (None): stage_evpi is a COMPUTED, EXACT value (including a genuine
          0.0), coupling_assumption absent.

        Rejects a fabricated skip status on a real value, a null value with no
        reason, a disclosed assumption with no value (or no coupling named), and a
        coupling_assumption not backed by its status."""
        value = self.stage_evpi
        status = self.stage_evpi_status
        coupling = self.coupling_assumption
        _SKIP_STATUSES = {
            "no_decision_node",
            "skipped_joint_space_too_large",
            "skipped_shared_chance_nodes_unsupported",
        }

        if status in _SKIP_STATUSES:
            ok = value is None and coupling is None
        elif status == "assumed_independent_coupling":
            ok = value is not None and coupling == "independence_across_actions"
        else:  # status is None
            ok = value is not None and coupling is None

        if not ok:
            raise ValueError(
                "stage_evpi/stage_evpi_status/coupling_assumption invariant violated: "
                f"stage_evpi={value!r}, stage_evpi_status={status!r}, "
                f"coupling_assumption={coupling!r}. A skip status carries a null value "
                "and no coupling; 'assumed_independent_coupling' carries a computed "
                "value and coupling_assumption='independence_across_actions'; no status "
                "carries a computed value (incl. 0.0) and no coupling."
            )
        return self


class SequentialAnalysisResponse(BaseModel):
    """Response model for sequential decision analysis.

    Arch step 1 (2026-07-26): `value_of_flexibility` and `sensitivity_to_timing`
    are OMITTED.

    `value_of_flexibility` reported `max(0, V_flexible - V_committed)`. The two
    legs were different ESTIMATORS of the same quantity, not two different
    quantities: `V_flexible` came from backward induction, which weights a
    chance node's branches by `_edge_probability`, while `V_committed` came from
    `_calculate_average_continuation`, which took `np.mean` over the same
    branches — the module's own probability reader was never called on that
    walk. On the adjudication's reproduction graph (one decision node, so
    nothing is ever chosen after the chance node resolves and the true value is
    definitionally 0) it reported 40.0: `mean(100, 0) = 50` against
    `0.9*100 + 0.1*0 = 90`. The error is deterministic, does not shrink with
    sample size, and scales with branch asymmetry.

    It is omitted rather than repaired because the repair is not a one-line
    change. Committing means choosing actions ex ante, WITHOUT conditioning on
    what the chance nodes reveal — which requires knowing which decision nodes
    across different histories are the same decision (an information set). This
    request schema has no way to express that: each history reaches its own
    node, so a correct estimator on the graph as given (max at decisions,
    probability-weighted expectation at chance) reproduces backward induction
    exactly and returns identically 0 for every input. The field cannot carry
    information until the request can express information sets. That is a
    modelling roadmap item.

    `sensitivity_to_timing` bucketed `value_of_flexibility / |best stage-0
    value|` at 0.3 / 0.1 into high/medium/low. It was a relabelling of the same
    number and carries the same defect, so it goes with it.

    Unaffected and still served: `optimal_policy` (backward induction),
    `stage_analyses`, `resolved_uncertainty`, `stage_evpi` and its disclosures.
    """

    schema_version: str = Field(
        default="sequential.v1", description="Schema version for this response"
    )
    optimal_policy: Policy = Field(..., description="Optimal policy across all stages")
    stage_analyses: List[StageAnalysis] = Field(..., description="Detailed analysis for each stage")

    # Metadata for determinism and reproducibility
    metadata: Optional[ResponseMetadata] = Field(
        default=None, description="Metadata for determinism verification", alias="_metadata"
    )

    model_config = {
        "populate_by_name": True,
        "json_schema_extra": {
            "example": {
                "schema_version": "sequential.v1",
                "optimal_policy": {
                    "stages": [
                        {
                            "stage_index": 0,
                            "stage_label": "Investment",
                            "decision_rule": {
                                "default_action": "invest",
                                "conditional_actions": [],
                            },
                            "contingent_on": [],
                        },
                        {
                            "stage_index": 1,
                            "stage_label": "Pricing",
                            "decision_rule": {
                                "default_action": "standard",
                                "conditional_actions": [
                                    {
                                        "condition": "If market_favorable",
                                        "action": "premium",
                                        "expected_value_if_taken": 100000,
                                    }
                                ],
                            },
                            "contingent_on": ["market_outcome"],
                        },
                    ],
                    "expected_total_value": 45000.0,
                },
                "stage_analyses": [
                    {
                        "stage_index": 0,
                        "stage_label": "Investment Decision",
                        "options_at_stage": [
                            {
                                "option_id": "invest",
                                "label": "Make Investment",
                                "immediate_value": -50000,
                                "continuation_value": 95000,
                                "total_value": 45000,
                            }
                        ],
                        "resolved_uncertainty": 15000.0,
                        "stage_evpi": 11220.0,
                        "stage_evpi_status": None,
                    }
                ],
            }
        }
    }


class PolicyTreeNode(BaseModel):
    """Node in a policy tree representation."""

    node_id: str = Field(..., description="Node identifier")
    stage: int = Field(..., description="Stage this node belongs to")
    node_type: str = Field(..., description="Type of node", pattern="^(decision|chance|terminal)$")
    label: str = Field(..., description="Human-readable label")
    optimal_action: Optional[str] = Field(
        default=None, description="Optimal action at this node (for decision nodes)"
    )
    expected_value: float = Field(..., description="Expected value at this node")
    children: List[Dict[str, Any]] = Field(
        default_factory=list, description="Child nodes with transition info"
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "node_id": "root",
                "stage": 0,
                "node_type": "decision",
                "label": "Investment Decision",
                "optimal_action": "invest",
                "expected_value": 45000,
                "children": [{"action": "invest", "child_id": "market_node", "probability": 1.0}],
            }
        }
    }


class PolicyTreeResponse(BaseModel):
    """Response model for policy tree endpoint."""

    schema_version: str = Field(default="policy_tree.v1", description="Schema version")
    root: PolicyTreeNode = Field(..., description="Root node of the policy tree")
    total_stages: int = Field(..., description="Total number of stages")
    total_nodes: int = Field(..., description="Total number of nodes in tree")

    # Metadata for determinism and reproducibility
    metadata: Optional[ResponseMetadata] = Field(
        default=None, description="Metadata for determinism verification", alias="_metadata"
    )

    model_config = {
        "populate_by_name": True,
        "json_schema_extra": {
            "example": {
                "schema_version": "policy_tree.v1",
                "root": {
                    "node_id": "root",
                    "stage": 0,
                    "node_type": "decision",
                    "label": "Investment Decision",
                    "optimal_action": "invest",
                    "expected_value": 45000,
                    "children": [],
                },
                "total_stages": 3,
                "total_nodes": 7,
            }
        }
    }


class StageSensitivityResult(BaseModel):
    """Sensitivity analysis result for a single stage."""

    stage_index: int = Field(..., description="Stage index")
    stage_label: str = Field(..., description="Stage label")
    parameter_sensitivities: Dict[str, float] = Field(
        ..., description="Mapping of parameter names to sensitivity scores"
    )
    policy_changes_at: Optional[Dict[str, float]] = Field(
        default=None, description="Parameter values where optimal policy changes"
    )
    robustness_score: float = Field(..., description="Stage robustness score (0-1)", ge=0.0, le=1.0)

    model_config = {
        "json_schema_extra": {
            "example": {
                "stage_index": 0,
                "stage_label": "Investment Decision",
                "parameter_sensitivities": {"market_probability": 0.85, "investment_cost": 0.45},
                "policy_changes_at": {"market_probability": 0.35},
                "robustness_score": 0.72,
            }
        }
    }


class StageSensitivityResponse(BaseModel):
    """Response model for stage sensitivity analysis."""

    schema_version: str = Field(default="stage_sensitivity.v1", description="Schema version")
    stage_results: List[StageSensitivityResult] = Field(
        ..., description="Sensitivity results for each stage"
    )
    overall_robustness: float = Field(
        ..., description="Overall policy robustness score", ge=0.0, le=1.0
    )
    most_sensitive_parameters: List[str] = Field(
        ..., description="Parameters with highest sensitivity"
    )
    explanation: ExplanationMetadata = Field(..., description="Plain English explanation")

    # Metadata for determinism and reproducibility
    metadata: Optional[ResponseMetadata] = Field(
        default=None, description="Metadata for determinism verification", alias="_metadata"
    )

    model_config = {
        "populate_by_name": True,
        "json_schema_extra": {
            "example": {
                "schema_version": "stage_sensitivity.v1",
                "stage_results": [
                    {
                        "stage_index": 0,
                        "stage_label": "Investment Decision",
                        "parameter_sensitivities": {
                            "market_probability": 0.85,
                            "investment_cost": 0.45,
                        },
                        "policy_changes_at": {"market_probability": 0.35},
                        "robustness_score": 0.72,
                    }
                ],
                "overall_robustness": 0.68,
                "most_sensitive_parameters": ["market_probability", "payoff_high"],
                "explanation": {
                    "summary": "Policy is moderately robust to parameter changes",
                    "reasoning": "Market probability has high sensitivity - small changes could flip optimal decision",
                    "technical_basis": "One-at-a-time sensitivity analysis with policy tracking",
                    "assumptions": ["Parameters vary independently"],
                },
            }
        }
    }


# ============================================================================
# Continuous Optimization Endpoint - Response Models
# ============================================================================


class OptimalPoint(BaseModel):
    """Optimal point found by optimization."""

    variable_values: Dict[str, float] = Field(
        ..., description="Optimal values for each decision variable"
    )
    objective_value: float = Field(..., description="Objective function value at optimal point")
    confidence_interval: ConfidenceInterval = Field(
        ..., description="Confidence interval for the objective value"
    )
    is_boundary: bool = Field(..., description="True if optimal point is on variable bounds")
    boundary_variables: Optional[List[str]] = Field(
        default=None, description="Variables at their bounds (if is_boundary=True)"
    )
    feasible: bool = Field(default=True, description="True if point satisfies all constraints")

    model_config = {
        "json_schema_extra": {
            "example": {
                "variable_values": {"price": 65.0, "quantity": 500.0},
                "objective_value": 22500.0,
                "confidence_interval": {
                    "lower": 21000.0,
                    "upper": 24000.0,
                    "confidence_level": 0.95,
                },
                "is_boundary": True,
                "boundary_variables": ["quantity"],
                "feasible": True,
            }
        }
    }


class OptimisationSensitivity(BaseModel):
    """Sensitivity analysis at the optimal point."""

    range_within_5pct: Dict[str, List[float]] = Field(
        ..., description="Variable ranges where objective stays within 5% of optimum [min, max]"
    )
    gradient_at_optimum: Dict[str, float] = Field(
        ..., description="Partial derivatives (sensitivity coefficients) at optimum"
    )
    robustness: str = Field(
        ..., description="Overall robustness assessment", pattern="^(robust|moderate|fragile)$"
    )
    robustness_score: float = Field(
        ..., description="Numerical robustness score (0-1)", ge=0.0, le=1.0
    )
    critical_variables: List[str] = Field(
        default_factory=list, description="Variables with highest sensitivity"
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "range_within_5pct": {"price": [60.0, 70.0], "quantity": [450.0, 500.0]},
                "gradient_at_optimum": {"price": 85.5, "quantity": -4.2},
                "robustness": "moderate",
                "robustness_score": 0.65,
                "critical_variables": ["quantity"],
            }
        }
    }


class OptimisationWarning(BaseModel):
    """Warning about optimization result."""

    code: str = Field(
        ...,
        description="Warning code",
        pattern="^(NO_FEASIBLE_SOLUTION|FLAT_OBJECTIVE|BOUNDARY_OPTIMUM|NON_CONVEX|MULTIPLE_OPTIMA|CONSTRAINT_ACTIVE)$",
    )
    message: str = Field(..., description="Human-readable warning message", max_length=500)
    affected_variables: Optional[List[str]] = Field(
        default=None, description="Variables affected by this warning"
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "code": "BOUNDARY_OPTIMUM",
                "message": "Optimal point is at constraint boundary for 'quantity'. Consider relaxing constraints.",
                "affected_variables": ["quantity"],
            }
        }
    }


class GridSearchMetrics(BaseModel):
    """Metrics from grid search optimization."""

    grid_points_evaluated: int = Field(..., description="Number of grid points evaluated", ge=0)
    feasible_points: int = Field(
        ..., description="Number of points satisfying all constraints", ge=0
    )
    computation_time_ms: float = Field(..., description="Computation time in milliseconds", ge=0)
    convergence_achieved: bool = Field(..., description="True if optimization converged")

    model_config = {
        "json_schema_extra": {
            "example": {
                "grid_points_evaluated": 400,
                "feasible_points": 350,
                "computation_time_ms": 125.5,
                "convergence_achieved": True,
            }
        }
    }


class OptimisationResponse(BaseModel):
    """Response model for continuous optimization endpoint."""

    schema_version: str = Field(
        default="optimise.v1", description="Schema version for this response"
    )
    optimal_point: Optional[OptimalPoint] = Field(
        default=None, description="Optimal point (None if no feasible solution)"
    )
    sensitivity: Optional[OptimisationSensitivity] = Field(
        default=None, description="Sensitivity analysis at optimal point"
    )
    grid_metrics: GridSearchMetrics = Field(..., description="Metrics from grid search")
    warnings: List[OptimisationWarning] = Field(
        default_factory=list, description="Warnings about the optimization result"
    )

    # Y₀ Identifiability fields (Task: Y₀ Hard Rule)
    identifiability: Optional["IdentifiabilityInfo"] = Field(
        default=None,
        description="Identifiability analysis for the primary decision→goal effect (if graph provided)",
    )
    recommendation_status: Optional["RecommendationStatusEnum"] = Field(
        default=None, description="HARD RULE: 'actionable' if identifiable, 'exploratory' if not"
    )
    recommendation_caveat: Optional[str] = Field(
        default=None,
        description="Caveat for recommendations (required if recommendation_status is 'exploratory')",
    )

    # Metadata for determinism and reproducibility
    metadata: Optional["ISLResponseMetadata"] = Field(
        default=None, description="Request metadata for tracing and monitoring"
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "schema_version": "optimise.v1",
                "optimal_point": {
                    "variable_values": {"price": 65.0, "quantity": 500.0},
                    "objective_value": 22500.0,
                    "confidence_interval": {
                        "lower": 21000.0,
                        "upper": 24000.0,
                        "confidence_level": 0.95,
                    },
                    "is_boundary": True,
                    "boundary_variables": ["quantity"],
                    "feasible": True,
                },
                "sensitivity": {
                    "range_within_5pct": {"price": [60.0, 70.0], "quantity": [450.0, 500.0]},
                    "gradient_at_optimum": {"price": 85.5, "quantity": -4.2},
                    "robustness": "moderate",
                    "robustness_score": 0.65,
                    "critical_variables": ["quantity"],
                },
                "grid_metrics": {
                    "grid_points_evaluated": 400,
                    "feasible_points": 350,
                    "computation_time_ms": 125.5,
                    "convergence_achieved": True,
                },
                "warnings": [
                    {
                        "code": "BOUNDARY_OPTIMUM",
                        "message": "Optimal point is at constraint boundary for 'quantity'.",
                        "affected_variables": ["quantity"],
                    }
                ],
                "metadata": {
                    "request_id": "opt_req_001",
                    "computation_time_ms": 125.5,
                    "isl_version": "2.0",
                    "algorithm": "grid_search",
                    "cache_hit": False,
                },
            }
        }
    }


# ============================================================================
# Feasibility Check Response Models
# ============================================================================


class ConstraintViolation(BaseModel):
    """Details of a constraint violation."""

    constraint_id: str = Field(..., description="ID of the violated constraint")
    constraint_label: Optional[str] = Field(None, description="Human-readable constraint label")
    actual_value: float = Field(..., description="Actual value that violated the constraint")
    threshold: float = Field(..., description="Threshold value that was violated")
    violation_magnitude: float = Field(..., description="How much the constraint was violated by")
    is_hard_violation: bool = Field(..., description="Whether this is a hard constraint violation")

    model_config = {
        "json_schema_extra": {
            "example": {
                "constraint_id": "budget_limit",
                "constraint_label": "Budget must not exceed $100,000",
                "actual_value": 120000,
                "threshold": 100000,
                "violation_magnitude": 20000,
                "is_hard_violation": True,
            }
        }
    }


class InfeasibleOption(BaseModel):
    """An option that violates one or more constraints."""

    option_id: str = Field(..., description="ID of the infeasible option")
    violated_constraints: List[str] = Field(
        ..., description="List of constraint IDs that were violated"
    )
    violation_details: List[ConstraintViolation] = Field(
        ..., description="Detailed information about each violation"
    )
    total_violation_magnitude: float = Field(..., description="Sum of all violation magnitudes")

    model_config = {
        "json_schema_extra": {
            "example": {
                "option_id": "option_c",
                "violated_constraints": ["budget_limit", "capacity"],
                "violation_details": [
                    {
                        "constraint_id": "budget_limit",
                        "actual_value": 120000,
                        "threshold": 100000,
                        "violation_magnitude": 20000,
                        "is_hard_violation": True,
                    }
                ],
                "total_violation_magnitude": 20000,
            }
        }
    }


class ConstraintValidationResult(BaseModel):
    """Result of validating a single constraint specification."""

    constraint_id: str = Field(..., description="ID of the constraint")
    is_valid: bool = Field(..., description="Whether the constraint is properly specified")
    issues: List[str] = Field(
        default_factory=list, description="List of issues with the constraint specification"
    )

    model_config = {
        "json_schema_extra": {
            "example": {"constraint_id": "budget_limit", "is_valid": True, "issues": []}
        }
    }


class FeasibilityResult(BaseModel):
    """Feasibility analysis results."""

    feasible_options: List[str] = Field(
        ..., description="List of option IDs that satisfy all constraints"
    )
    infeasible_options: List[InfeasibleOption] = Field(
        ..., description="Options that violate constraints with details"
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "feasible_options": ["option_1", "option_2"],
                "infeasible_options": [
                    {
                        "option_id": "option_3",
                        "violated_constraints": ["budget_constraint"],
                        "violation_details": [],
                        "total_violation_magnitude": 5000,
                    }
                ],
            }
        }
    }


class FeasibilityResponse(BaseModel):
    """Response model for feasibility check endpoint."""

    schema_version: str = Field(default="feasibility.v1", description="Schema version")
    constraint_validation: List[ConstraintValidationResult] = Field(
        ..., description="Validation results for constraint specifications"
    )
    feasibility: FeasibilityResult = Field(..., description="Feasibility analysis results")
    summary: str = Field(..., description="Human-readable summary of results")
    warnings: List[str] = Field(
        default_factory=list, description="Any warnings generated during analysis"
    )

    # Metadata for determinism and reproducibility
    metadata: Optional["ISLResponseMetadata"] = Field(
        default=None, description="Request metadata for tracing and monitoring"
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "schema_version": "feasibility.v1",
                "constraint_validation": [
                    {"constraint_id": "budget", "is_valid": True, "issues": []}
                ],
                "feasibility": {
                    "feasible_options": ["option_1", "option_2"],
                    "infeasible_options": [
                        {
                            "option_id": "option_3",
                            "violated_constraints": ["budget_constraint"],
                            "violation_details": [],
                            "total_violation_magnitude": 5000,
                        }
                    ],
                },
                "summary": "2 of 3 options are feasible",
                "warnings": [],
            }
        }
    }


# ============================================================================
# Coherence Analysis Response Models
# ============================================================================


class RankingStability(str, Enum):
    """Ranking stability classification."""

    STABLE = "stable"
    SENSITIVE = "sensitive"
    UNSTABLE = "unstable"


class CoherenceAnalysis(BaseModel):
    """Coherence analysis results."""

    top_option_positive: bool = Field(
        ..., description="Whether the top option has positive expected value"
    )
    margin_to_second: float = Field(..., description="Margin between top option and second-best")
    margin_to_second_pct: float = Field(
        ..., description="Margin as percentage of top option's value"
    )
    ranking_stability: RankingStability = Field(
        ..., description="Stability classification of rankings"
    )
    stability_score: float = Field(
        ..., description="Numerical stability score (0-1, higher is more stable)", ge=0.0, le=1.0
    )
    warnings: List[str] = Field(
        default_factory=list, description="Coherence warnings and edge case flags"
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "top_option_positive": True,
                "margin_to_second": 2000,
                "margin_to_second_pct": 4.0,
                "ranking_stability": "sensitive",
                "stability_score": 0.65,
                "warnings": ["Close race detected between top options"],
            }
        }
    }


class PerturbationResult(BaseModel):
    """Result of a single perturbation scenario."""

    perturbation_id: int = Field(..., description="Perturbation scenario ID")
    top_option_id: str = Field(..., description="ID of top option in this scenario")
    ranking_changed: bool = Field(..., description="Whether ranking changed from baseline")
    value_change_pct: float = Field(..., description="Percentage change in top option's value")

    model_config = {
        "json_schema_extra": {
            "example": {
                "perturbation_id": 1,
                "top_option_id": "option_b",
                "ranking_changed": True,
                "value_change_pct": -3.5,
            }
        }
    }


class StabilityAnalysis(BaseModel):
    """Detailed stability analysis from perturbations."""

    num_perturbations: int = Field(..., description="Number of perturbations performed")
    ranking_changes: int = Field(..., description="Number of times ranking changed")
    ranking_change_rate: float = Field(
        ..., description="Rate of ranking changes (0-1)", ge=0.0, le=1.0
    )
    most_frequent_alternative: Optional[str] = Field(
        None, description="Option that most often took top rank when changed"
    )
    sample_perturbations: List[PerturbationResult] = Field(
        default_factory=list, description="Sample of perturbation results", max_length=10
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "num_perturbations": 100,
                "ranking_changes": 35,
                "ranking_change_rate": 0.35,
                "most_frequent_alternative": "option_b",
                "sample_perturbations": [],
            }
        }
    }


class CoherenceAnalysisResponse(BaseModel):
    """Response model for coherence analysis endpoint."""

    schema_version: str = Field(default="coherence.v1", description="Schema version")
    coherence_analysis: CoherenceAnalysis = Field(..., description="Core coherence metrics")
    stability_analysis: StabilityAnalysis = Field(..., description="Detailed stability analysis")
    recommendations: List[str] = Field(
        default_factory=list, description="Actionable recommendations based on analysis"
    )

    # Metadata for determinism and reproducibility
    metadata: Optional["ISLResponseMetadata"] = Field(
        default=None, description="Request metadata for tracing and monitoring"
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "schema_version": "coherence.v1",
                "coherence_analysis": {
                    "top_option_positive": True,
                    "margin_to_second": 2000,
                    "margin_to_second_pct": 4.0,
                    "ranking_stability": "sensitive",
                    "stability_score": 0.65,
                    "warnings": ["Close race detected between top options"],
                },
                "stability_analysis": {
                    "num_perturbations": 100,
                    "ranking_changes": 35,
                    "ranking_change_rate": 0.35,
                    "most_frequent_alternative": "option_b",
                    "sample_perturbations": [],
                },
                "recommendations": [
                    "Consider gathering more data to reduce uncertainty",
                    "Top options are close - decision may depend on risk tolerance",
                ],
            }
        }
    }


# ============================================================================
# Utility Function Validation Response Models
# ============================================================================


class NormalisedGoal(BaseModel):
    """Normalised goal specification after validation."""

    goal_id: str = Field(..., description="Goal identifier")
    label: str = Field(..., description="Goal label")
    direction: str = Field(..., description="Optimization direction")
    normalised_weight: float = Field(
        ..., description="Weight after normalization (sums to 1.0)", ge=0.0, le=1.0
    )
    original_weight: Optional[float] = Field(
        None, description="Original weight before normalization"
    )
    priority: Optional[int] = Field(None, description="Priority for lexicographic ordering")

    model_config = {
        "json_schema_extra": {
            "example": {
                "goal_id": "revenue",
                "label": "Maximize Revenue",
                "direction": "maximize",
                "normalised_weight": 0.6,
                "original_weight": 0.6,
                "priority": 1,
            }
        }
    }


class UtilityValidationWarning(BaseModel):
    """Warning from utility validation."""

    code: str = Field(..., description="Warning code")
    message: str = Field(..., description="Human-readable warning message")
    affected_goals: Optional[List[str]] = Field(None, description="List of goal IDs affected")

    model_config = {
        "json_schema_extra": {
            "example": {
                "code": "WEIGHTS_NORMALIZED",
                "message": "Weights normalized from sum=1.5 to sum=1.0",
                "affected_goals": ["revenue", "cost", "quality"],
            }
        }
    }


class UtilityValidationResponse(BaseModel):
    """Response model for utility function validation endpoint."""

    schema_version: str = Field(default="utility.v1", description="Schema version")
    valid: bool = Field(..., description="Whether the utility specification is valid")
    normalised_weights: Dict[str, float] = Field(
        ..., description="Normalized weights by goal ID (sum to 1.0)"
    )
    normalised_goals: List[NormalisedGoal] = Field(
        ..., description="Full normalised goal specifications"
    )
    aggregation_method: str = Field(..., description="Aggregation method to be used")
    risk_tolerance: str = Field(..., description="Risk tolerance setting")
    default_behaviour_applied: List[str] = Field(
        default_factory=list, description="List of default behaviours that were applied"
    )
    warnings: List[UtilityValidationWarning] = Field(
        default_factory=list, description="Validation warnings"
    )
    errors: List[str] = Field(
        default_factory=list, description="Validation errors (if valid=false)"
    )

    # Metadata for tracing
    metadata: Optional["ISLResponseMetadata"] = Field(
        default=None, description="Request metadata for tracing and monitoring"
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "schema_version": "utility.v1",
                "valid": True,
                "normalised_weights": {"revenue": 0.6, "cost": 0.4},
                "normalised_goals": [
                    {
                        "goal_id": "revenue",
                        "label": "Revenue",
                        "direction": "maximize",
                        "normalised_weight": 0.6,
                    }
                ],
                "aggregation_method": "weighted_sum",
                "risk_tolerance": "risk_neutral",
                "default_behaviour_applied": [],
                "warnings": [],
            }
        }
    }


# ============================================================================
# Factor Correlation Groups Response Models
# ============================================================================


class ValidatedCorrelationGroup(BaseModel):
    """Validated correlation group with additional metadata."""

    group_id: str = Field(..., description="Group identifier")
    factors: List[str] = Field(..., description="Factor IDs in the group")
    correlation: float = Field(..., description="Correlation coefficient")
    is_valid: bool = Field(..., description="Whether this group specification is valid")
    issues: List[str] = Field(default_factory=list, description="Issues with this group")

    model_config = {
        "json_schema_extra": {
            "example": {
                "group_id": "market_conditions",
                "factors": ["demand", "competition"],
                "correlation": 0.7,
                "is_valid": True,
                "issues": [],
            }
        }
    }


class CorrelationMatrixAnalysis(BaseModel):
    """Analysis of the correlation matrix."""

    is_positive_semi_definite: bool = Field(
        ..., description="Whether matrix is positive semi-definite (valid for sampling)"
    )
    min_eigenvalue: Optional[float] = Field(
        None, description="Minimum eigenvalue (negative indicates not PSD)"
    )
    condition_number: Optional[float] = Field(
        None, description="Condition number (high values indicate near-singularity)"
    )
    suggested_regularization: Optional[float] = Field(
        None, description="Suggested regularization if matrix is not PSD"
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "is_positive_semi_definite": True,
                "min_eigenvalue": 0.15,
                "condition_number": 3.2,
                "suggested_regularization": None,
            }
        }
    }


class ImpliedCorrelationMatrix(BaseModel):
    """The implied correlation matrix from groups."""

    factors: List[str] = Field(..., description="Factor IDs in matrix order")
    matrix: List[List[float]] = Field(..., description="Correlation matrix values")

    model_config = {
        "json_schema_extra": {
            "example": {"factors": ["demand", "competition"], "matrix": [[1.0, 0.7], [0.7, 1.0]]}
        }
    }


class CorrelationValidationWarning(BaseModel):
    """Warning from correlation validation."""

    code: str = Field(..., description="Warning code")
    message: str = Field(..., description="Human-readable warning message")
    affected_groups: Optional[List[str]] = Field(
        None, description="Group IDs affected by this warning"
    )
    affected_factors: Optional[List[str]] = Field(
        None, description="Factor IDs affected by this warning"
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "code": "HIGH_CORRELATION",
                "message": "Correlation of 0.95 between demand and sales may indicate redundancy",
                "affected_factors": ["demand", "sales"],
            }
        }
    }


class CorrelationValidationResponse(BaseModel):
    """Response model for correlation validation endpoint."""

    schema_version: str = Field(default="correlation.v1", description="Schema version")
    valid: bool = Field(
        ..., description="Whether the correlation specification is valid for sampling"
    )
    validated_groups: List[ValidatedCorrelationGroup] = Field(
        default_factory=list, description="Validation results for each correlation group"
    )
    implied_matrix: Optional[ImpliedCorrelationMatrix] = Field(
        None, description="The implied correlation matrix from groups"
    )
    matrix_analysis: Optional[CorrelationMatrixAnalysis] = Field(
        None, description="Analysis of the correlation matrix properties"
    )
    warnings: List[CorrelationValidationWarning] = Field(
        default_factory=list, description="Validation warnings"
    )
    errors: List[str] = Field(
        default_factory=list, description="Validation errors (if valid=false)"
    )

    # Metadata for tracing
    metadata: Optional["ISLResponseMetadata"] = Field(
        default=None, description="Request metadata for tracing and monitoring"
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "schema_version": "correlation.v1",
                "valid": True,
                "validated_groups": [
                    {
                        "group_id": "market_conditions",
                        "factors": ["demand", "competition"],
                        "correlation": 0.7,
                        "is_valid": True,
                        "issues": [],
                    }
                ],
                "matrix_analysis": {
                    "is_positive_semi_definite": True,
                    "min_eigenvalue": 0.3,
                    "condition_number": 2.5,
                },
                "warnings": [],
            }
        }
    }


# ============================================================================
# Y₀ Identifiability Analysis Response Models
# ============================================================================


class IdentificationMethodEnum(str, Enum):
    """Method used for causal identification."""

    BACKDOOR = "backdoor"
    FRONTDOOR = "frontdoor"
    INSTRUMENTAL = "instrumental"
    DO_CALCULUS = "do_calculus"
    NON_IDENTIFIABLE = "non_identifiable"


class RecommendationStatusEnum(str, Enum):
    """Status of recommendations based on identifiability (hard rule)."""

    ACTIONABLE = "actionable"  # Effect is identifiable, recommendations reliable
    EXPLORATORY = "exploratory"  # Effect NOT identifiable, treat as hypotheses


class IdentifiabilitySuggestionResponse(BaseModel):
    """Suggestion for making an effect identifiable."""

    description: str = Field(
        ..., description="Human-readable suggestion for making effect identifiable"
    )
    variable_to_add: Optional[str] = Field(
        None, description="Variable that could be added to enable identification"
    )
    edges_to_add: Optional[List[Tuple[str, str]]] = Field(
        None, description="Edges that could be added to enable identification"
    )
    priority: str = Field(
        default="recommended", description="Priority: 'critical', 'recommended', 'optional'"
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "description": "Adding 'market_conditions' as an observed factor would enable backdoor adjustment",
                "variable_to_add": "market_conditions_observed",
                "edges_to_add": [
                    ["market_conditions_observed", "price"],
                    ["market_conditions_observed", "revenue"],
                ],
                "priority": "recommended",
            }
        }
    }


class IdentifiabilityInfo(BaseModel):
    """
    Structured identifiability information for causal effects.

    This implements the Y₀ identifiability analysis as specified,
    including the hard rule for non-identifiable effects.
    """

    effect: str = Field(
        ..., description="The causal effect being analyzed (e.g., 'decision → goal')"
    )
    identifiable: bool = Field(
        ..., description="Whether the causal effect is identifiable from observational data"
    )
    method: Optional[IdentificationMethodEnum] = Field(
        None,
        description="Method used for identification: backdoor, frontdoor, instrumental, do_calculus, or non_identifiable",
    )
    adjustment_set: Optional[List[str]] = Field(
        None, description="Variables to condition on for identification (if identifiable)"
    )
    confidence: ConfidenceLevel = Field(
        ..., description="Confidence in the identifiability assessment"
    )
    explanation: str = Field(
        ..., description="Human-readable explanation of identifiability status"
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "effect": "price → revenue",
                "identifiable": True,
                "method": "backdoor",
                "adjustment_set": ["market_segment"],
                "confidence": "high",
                "explanation": "The effect of 'price' on 'revenue' is identifiable using the backdoor criterion. Adjust for: market_segment.",
            }
        }
    }


class IdentifiabilityResponse(BaseModel):
    """
    Response model for Y₀ identifiability analysis endpoint.

    Implements the hard rule: if primary decision→goal effect is non-identifiable,
    recommendations are marked as 'exploratory' rather than 'actionable'.
    """

    schema_version: str = Field(
        default="identifiability.v1", description="Schema version for this response"
    )
    identifiability: IdentifiabilityInfo = Field(
        ..., description="Core identifiability analysis results"
    )
    recommendation_status: RecommendationStatusEnum = Field(
        ..., description="HARD RULE: 'actionable' if identifiable, 'exploratory' if not"
    )
    recommendation_caveat: Optional[str] = Field(
        None, description="Caveat for recommendations if effect is non-identifiable"
    )
    suggestions: Optional[List[IdentifiabilitySuggestionResponse]] = Field(
        None, description="Suggestions for making effect identifiable (if non-identifiable)"
    )
    backdoor_paths: Optional[List[str]] = Field(
        None, description="Backdoor paths identified in the graph"
    )

    # Metadata for tracing
    metadata: Optional["ISLResponseMetadata"] = Field(
        default=None, description="Request metadata for tracing and monitoring"
    )

    model_config = {
        "json_schema_extra": {
            "examples": [
                {
                    "title": "Identifiable Effect",
                    "value": {
                        "schema_version": "identifiability.v1",
                        "identifiability": {
                            "effect": "price → revenue",
                            "identifiable": True,
                            "method": "backdoor",
                            "adjustment_set": ["market_segment"],
                            "confidence": "high",
                            "explanation": "The effect of 'price' on 'revenue' is identifiable using the backdoor criterion. Adjust for: market_segment.",
                        },
                        "recommendation_status": "actionable",
                        "recommendation_caveat": None,
                        "suggestions": None,
                        "backdoor_paths": ["price → market_segment → revenue"],
                    },
                },
                {
                    "title": "Non-Identifiable Effect (Hard Rule Applied)",
                    "value": {
                        "schema_version": "identifiability.v1",
                        "identifiability": {
                            "effect": "marketing_spend → sales",
                            "identifiable": False,
                            "method": "non_identifiable",
                            "adjustment_set": None,
                            "confidence": "high",
                            "explanation": "The effect of 'marketing_spend' on 'sales' is NOT identifiable. There is unmeasured confounding that cannot be blocked.",
                        },
                        "recommendation_status": "exploratory",
                        "recommendation_caveat": "Causal effect cannot be confirmed from current model structure. Recommendations should be treated as exploratory hypotheses, not actionable conclusions.",
                        "suggestions": [
                            {
                                "description": "If 'market_conditions' were observed as a confounder, conditioning on it might block the backdoor path",
                                "variable_to_add": "market_conditions_observed",
                                "priority": "recommended",
                            },
                            {
                                "description": "Adding an instrumental variable that affects 'marketing_spend' but not 'sales' directly could enable identification",
                                "variable_to_add": "marketing_spend_instrument",
                                "edges_to_add": [["marketing_spend_instrument", "marketing_spend"]],
                                "priority": "recommended",
                            },
                        ],
                        "backdoor_paths": ["marketing_spend → unmeasured_confounder → sales"],
                    },
                },
            ]
        }
    }


class IdentifiabilityEnhancedResponse(BaseModel):
    """
    Mixin for responses that include identifiability information.

    Used to add identifiability to existing response models like
    OptimisationResponse and MultiCriteriaResponse.
    """

    identifiability: Optional[IdentifiabilityInfo] = Field(
        None, description="Identifiability analysis for the primary decision→goal effect"
    )
    recommendation_status: Optional[RecommendationStatusEnum] = Field(
        None, description="HARD RULE: 'actionable' if identifiable, 'exploratory' if not"
    )
    recommendation_caveat: Optional[str] = Field(
        None,
        description="Caveat for recommendations (required if recommendation_status is 'exploratory')",
    )


# ============================================================================
# V2 Identifiability Response (3B-prep)
# ============================================================================


class IdentifiabilityV2PairResult(BaseModel):
    """Identifiability result for a single (treatment, outcome) pair."""

    treatment_node_id: str = Field(..., description="Treatment / factor node ID")
    outcome_node_id: str = Field(..., description="Outcome / goal node ID")
    identifiable: bool = Field(..., description="Whether the causal effect is identifiable")
    method: Optional[str] = Field(
        None,
        description="Identification method (backdoor, frontdoor, do_calculus, non_identifiable)",
    )
    adjustment_set: Optional[List[str]] = Field(
        None, description="Variables to condition on (for backdoor/frontdoor)"
    )
    estimand: Optional[str] = Field(
        None, description="Symbolic estimand expression from Y₀ (when available)"
    )


class ConfoundingPairResponse(BaseModel):
    """Sensitivity result for a single bidirected (confounded) pair."""

    node_a: str = Field(..., description="First node in bidirected pair")
    node_b: str = Field(..., description="Second node in bidirected pair")
    flip_threshold_raw: Optional[float] = Field(
        None, description="Absolute edge strength at which recommendation flips"
    )
    flip_threshold_relative: Optional[float] = Field(
        None, description="Multiple of median edge strength (interpretable threshold)"
    )
    baseline_winner: str = Field(..., description="Recommended option at confounder_strength=0")
    flipped_winner: Optional[str] = Field(None, description="Recommended option after flip, if any")
    interpretation: str = Field(..., description="Human-readable interpretation (provisional)")


class ConfoundingSensitivityResponse(BaseModel):
    """Aggregate confounding sensitivity result."""

    pairs: List[ConfoundingPairResponse] = Field(
        ..., description="Per-bidirected-pair sensitivity results"
    )
    overall_robust: bool = Field(
        ..., description="True if no pair flips at any confounder strength"
    )
    median_edge_strength: float = Field(
        ..., description="Graph-level reference: median |edge strength|"
    )


class IdentifiabilityV2Response(BaseModel):
    """Response for /v2/identifiability endpoint."""

    pairs: List[IdentifiabilityV2PairResult] = Field(
        ..., description="Per-pair identifiability results"
    )
    all_identifiable: bool = Field(
        ..., description="True if every (treatment, outcome) pair is identifiable"
    )
    confounding_sensitivity: Optional[ConfoundingSensitivityResponse] = Field(
        None,
        description="Confounding sensitivity analysis (present when non-identifiable pairs exist). "
        "Provisional — pending scientific review.",
    )
