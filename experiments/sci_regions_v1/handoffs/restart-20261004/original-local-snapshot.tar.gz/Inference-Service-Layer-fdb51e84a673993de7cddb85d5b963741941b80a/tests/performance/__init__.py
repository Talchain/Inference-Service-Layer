"""Performance tests for ISL."""
