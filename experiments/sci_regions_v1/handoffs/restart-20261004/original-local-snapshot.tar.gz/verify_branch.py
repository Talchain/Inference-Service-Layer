import json
import subprocess
from pathlib import Path

repo = "Talchain/Inference-Service-Layer"
commit = "30af9938d20bcf66e34b44940a081f2e03955002"
base = "fdb51e84a673993de7cddb85d5b963741941b80a"
root = Path("/private/tmp/sci-regions-v1/Inference-Service-Layer-fdb51e84a673993de7cddb85d5b963741941b80a/experiments/sci_regions_v1")

def api(endpoint):
    r = subprocess.run(["gh", "api", f"repos/{repo}/{endpoint}"], check=True, capture_output=True, timeout=45)
    return json.loads(r.stdout)

data = api(f"git/commits/{commit}")
assert [p["sha"] for p in data["parents"]] == [base]
tree = api(f"git/trees/{data['tree']['sha']}?recursive=1")
assert not tree.get("truncated")
prefix = "experiments/sci_regions_v1/"
found = {e["path"][len(prefix):]: e["sha"] for e in tree["tree"] if e["path"].startswith(prefix) and e["type"] == "blob"}
assert len(found) == 20, len(found)
for name, remote_sha in found.items():
    local_sha = subprocess.run(["git", "hash-object", str(root / name)], check=True, capture_output=True, text=True).stdout.strip()
    assert local_sha == remote_sha, name
print(json.dumps({"commit": commit, "parent": base, "files_verified": len(found), "tree_truncated": tree.get("truncated")}))
